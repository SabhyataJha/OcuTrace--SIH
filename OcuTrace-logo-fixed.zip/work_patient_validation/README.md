# OcuTrace Frontend

React + Vite + Tailwind MVP for the SIH26038 explainable diabetic retinopathy screening project.

## Run

```bash
npm install
npm run dev
```

Open http://localhost:5173

## Current state

The UI is fully navigable and currently uses mock screening data.

The API adapter lives at:

`src/services/api.js`

Replace those mock functions with the agreed FastAPI calls once the backend contract is frozen.

## Core flows

Health Worker:
- Dashboard
- New Screening
- Patient details
- Fundus upload
- Processing pipeline

Doctor:
- Review Queue
- Screening Review
- Evidence viewer
- DR grade + class probabilities
- Calibrated confidence
- Referable/Routine
- Confirm/Override
- Report

## Important integration boundary

The frontend intentionally does not implement Grad-CAM, lesion segmentation, calibration, or the decision engine. It renders their outputs from the API.

Expected evidence payload shape can be adapted in `src/services/api.js` / `src/mockData.js`.

## Suggested environment variable

Create `.env`:

```bash
VITE_API_BASE_URL=http://localhost:8000
```

Then change the API adapter from mock responses to FastAPI responses.
