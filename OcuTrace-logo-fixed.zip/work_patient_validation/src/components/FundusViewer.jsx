import React, { useEffect, useState } from "react";
import { Contrast, Eye, Layers3, Maximize2, Minus, Plus, RotateCcw, ScanSearch } from "lucide-react";

const tabs = [
  { id: "original", label: "Original", icon: Eye },
  { id: "gradcam", label: "AI Attention", icon: Contrast },
  { id: "lesions", label: "Lesion Map", icon: Layers3 },
  { id: "combined", label: "Combined", icon: ScanSearch },
];

export default function FundusViewer({ screening, activeLayer = "original", onActiveLayerChange }) {
  const [active, setActive] = useState(activeLayer);

  function changeLayer(next) {
    setActive(next);
    onActiveLayerChange?.(next);
  }
  const image =
    active === "gradcam"
      ? screening.evidence.gradCamUrl
      : active === "combined"
      ? screening.evidence.combinedEvidenceUrl
      : screening.imageUrl;

  const [zoom, setZoom] = useState(1);
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    setImageError(false);
  }, [image, active]);

  return (
    <div className="overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-clinical">
      <div className="border-b border-slate-100 bg-white px-5 py-4">
        <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
          <div>
            <div className="flex items-center gap-2 text-[14px] font-extrabold text-slate-950">
              <span className="grid h-8 w-8 place-items-center rounded-xl bg-teal-50 text-teal-700"><Eye size={15} /></span>
              Retinal evidence
            </div>
            <div className="mt-1 text-[10px] text-slate-400">Inspect the same image through each evidence layer</div>
          </div>
          <div className={[
            "inline-flex w-fit items-center gap-2 rounded-full px-3 py-1.5 text-[10px] font-extrabold",
            imageError ? "border border-amber-100 bg-amber-50 text-amber-800" : "border border-emerald-100 bg-emerald-50 text-emerald-800",
          ].join(" ")}>
            <span className={["h-1.5 w-1.5 rounded-full", imageError ? "bg-amber-500" : "bg-emerald-500"].join(" ")} />
            {imageError ? "Fallback image shown" : "Image loaded"}
          </div>
        </div>

        <div className="mt-4 flex overflow-x-auto rounded-xl bg-slate-100 p-1 scrollbar-thin">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => changeLayer(id)}
              className={[
                "flex shrink-0 items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-[11px] font-extrabold transition",
                active === id ? "bg-white text-clinical-800 shadow-sm" : "text-slate-500 hover:text-slate-800",
              ].join(" ")}
            >
              <Icon size={14} /> {label}
            </button>
          ))}
        </div>
      </div>

      <div className="relative flex min-h-[460px] items-center justify-center overflow-hidden bg-slate-950 p-5 md:p-7">
        <div className="absolute left-4 top-4 z-10 rounded-full border border-white/10 bg-slate-950/75 px-3 py-1.5 text-[9px] font-extrabold text-white/85 backdrop-blur">
          {active === "original" ? "Original capture" : active === "gradcam" ? "Grad-CAM attention" : active === "lesions" ? "Lesion evidence" : "Evidence fusion"}
        </div>

        <div
          className="scan-ring relative aspect-square w-[min(100%,560px)] overflow-hidden rounded-full bg-black transition-transform duration-200"
          style={{ transform: `scale(${zoom})` }}
        >
          {imageError ? (
            <div className="relative h-full w-full">
              <img
                src="/fundus-placeholder.svg"
                alt="Retinal image placeholder"
                className="h-full w-full object-contain"
              />
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full border border-white/10 bg-slate-950/80 px-3 py-1.5 text-[9px] font-bold text-white/80 backdrop-blur">
                Demo retinal image · source unavailable
              </div>
            </div>
          ) : (
            <img
              src={image || "/fundus-placeholder.svg"}
              alt="Fundus retinal scan"
              className="h-full w-full object-contain"
              onError={() => setImageError(true)}
            />
          )}

          {active === "gradcam" && (
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_58%_45%,rgba(239,68,68,.60),transparent_17%),radial-gradient(circle_at_38%_66%,rgba(245,158,11,.50),transparent_21%),radial-gradient(circle_at_65%_65%,rgba(234,179,8,.28),transparent_16%)] mix-blend-screen" />
          )}

          {active === "lesions" && (
            <div className="pointer-events-none absolute inset-0">
              <span className="absolute left-[29%] top-[33%] grid h-9 w-9 place-items-center rounded-full border-2 border-white bg-rose-500/70 shadow-[0_0_0_6px_rgba(244,63,94,.18),0_0_28px_rgba(244,63,94,.55)]">
                <span className="h-2 w-2 rounded-full bg-white" />
              </span>
              <span className="absolute left-[58%] top-[46%] grid h-7 w-7 place-items-center rounded-full border-2 border-white bg-amber-400/80 shadow-[0_0_0_6px_rgba(251,191,36,.18),0_0_24px_rgba(251,191,36,.5)]">
                <span className="h-1.5 w-1.5 rounded-full bg-white" />
              </span>
              <span className="absolute left-[53%] top-[61%] grid h-10 w-10 place-items-center rounded-full border-2 border-white bg-rose-500/65 shadow-[0_0_0_6px_rgba(244,63,94,.16),0_0_28px_rgba(244,63,94,.45)]">
                <span className="h-2 w-2 rounded-full bg-white" />
              </span>
            </div>
          )}

          {active === "combined" && (
            <>
              <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_58%_45%,rgba(239,68,68,.40),transparent_17%),radial-gradient(circle_at_38%_66%,rgba(245,158,11,.35),transparent_21%)] mix-blend-screen" />
              <div className="pointer-events-none absolute inset-0">
                <span className="absolute left-[29%] top-[33%] h-9 w-9 rounded-full border-2 border-white bg-rose-500/60 shadow-[0_0_0_5px_rgba(244,63,94,.15)]" />
                <span className="absolute left-[58%] top-[46%] h-7 w-7 rounded-full border-2 border-white bg-amber-400/70 shadow-[0_0_0_5px_rgba(251,191,36,.13)]" />
              </div>
            </>
          )}
        </div>

        <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 items-center gap-1 rounded-xl border border-white/10 bg-slate-950/85 p-1 backdrop-blur">
          <button onClick={() => setZoom((z) => Math.max(1, z - 0.1))} className="rounded-lg p-2 text-white/70 hover:bg-white/10 hover:text-white"><Minus size={15} /></button>
          <div className="px-2 text-[10px] font-extrabold text-white/70">{Math.round(zoom * 100)}%</div>
          <button onClick={() => setZoom((z) => Math.min(1.5, z + 0.1))} className="rounded-lg p-2 text-white/70 hover:bg-white/10 hover:text-white"><Plus size={15} /></button>
          <div className="mx-1 h-4 w-px bg-white/10" />
          <button onClick={() => setZoom(1)} className="rounded-lg p-2 text-white/70 hover:bg-white/10 hover:text-white"><RotateCcw size={15} /></button>
          <button className="rounded-lg p-2 text-white/70 hover:bg-white/10 hover:text-white" title="Fullscreen"><Maximize2 size={15} /></button>
        </div>
      </div>

      <div className="grid grid-cols-2 border-t border-slate-100 sm:grid-cols-4">
        {[
          ["Original", "Raw fundus image", "text-slate-700"],
          ["AI Attention", "Classifier focus", "text-[#2b6cb0]"],
          ["Lesions", "Pixel-level evidence", "text-rose-700"],
          ["Combined", "Fused evidence", "text-clinical-700"],
        ].map(([title, body, tone]) => (
          <button key={title} onClick={() => changeLayer(title === "AI Attention" ? "gradcam" : title === "Lesions" ? "lesions" : title === "Combined" ? "combined" : "original")} className="border-r border-slate-100 px-3 py-3 text-left last:border-r-0 hover:bg-slate-50">
            <div className={`text-[9px] font-extrabold ${tone}`}>{title}</div>
            <div className="mt-1 text-[9px] text-slate-400">{body}</div>
          </button>
        ))}
      </div>
      <div className="flex items-center justify-between gap-3 border-t border-slate-100 bg-slate-50/70 px-5 py-3 text-[10px] text-slate-500">
        <span className="font-semibold">Evidence supports clinician review; it does not independently establish a diagnosis.</span>
        <span className="hidden font-extrabold text-slate-400 sm:block">Screening image</span>
      </div>
    </div>
  );
}
