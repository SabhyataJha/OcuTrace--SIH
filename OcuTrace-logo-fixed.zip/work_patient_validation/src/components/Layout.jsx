import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import {
  Activity,
  ClipboardCheck,
  FileText,
  Home,
  LogOut,
  Menu,
  ScanEye,
  Settings,
  UsersRound,
  X,
  Stethoscope,
  BarChart3,
} from "lucide-react";

const nav = [
  { to: "/", label: "Dashboard", icon: Home },
  { to: "/screen/new", label: "New Screening", icon: ScanEye },
  { to: "/queue", label: "Review Queue", icon: ClipboardCheck },
  { to: "/patients", label: "Patient Records", icon: UsersRound },
  { to: "/reports", label: "Clinical Reports", icon: FileText },
];

export default function Layout({ children }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#f5f9fc] text-slate-900">
      {open && <button aria-label="Close menu" className="fixed inset-0 z-30 bg-slate-950/35 lg:hidden" onClick={() => setOpen(false)} />}

      <aside className={["ocutrace-sidebar", open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"].join(" ")}>
        <div className="ocutrace-brand ocutrace-brand-light">
          <img src="/ocutrace-logo.png" alt="OcuTrace" className="ocutrace-logo" />
        </div>

        <div className="ocutrace-nav-label">Workspace</div>
        <nav className="ocutrace-nav">
          {nav.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} end={to === "/"} onClick={() => setOpen(false)} className={({ isActive }) => `ocutrace-nav-item ${isActive ? "active" : ""}`}>
              <Icon size={17} strokeWidth={1.9} />
              <span>{label}</span>
              {to === "/queue" && <span className="ocutrace-nav-pill">Review</span>}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto px-3 pb-4">
          <div className="ocutrace-system-card">
            <div className="flex items-center gap-2 text-[11px] font-extrabold text-white"><Activity size={14} /> Screening system</div>
            <div className="mt-2 flex items-center gap-2 text-[10px] text-white/70"><span className="ocutrace-status-dot" /> Local demo services ready</div>
          </div>
          <div className="ocutrace-profile">
            <div className="ocutrace-avatar">AS</div>
            <div className="min-w-0 flex-1"><div className="truncate text-[12px] font-extrabold text-white">Dr. A. Sharma</div><div className="text-[10px] text-white/55">Ophthalmologist</div></div>
            <Settings size={15} className="text-white/45" />
          </div>
          <button className="ocutrace-logout"><LogOut size={15} /> Log out</button>
        </div>
        <button onClick={() => setOpen(false)} className="absolute right-3 top-3 rounded-lg p-2 text-white/60 lg:hidden"><X size={18} /></button>
      </aside>

      <div className="lg:pl-[222px]">
        <header className="ocutrace-topbar">
          <div className="flex items-center gap-3">
            <button onClick={() => setOpen(true)} className="rounded-xl p-2 text-slate-500 lg:hidden"><Menu size={20} /></button>
            <div><div className="text-[13px] font-extrabold text-[#102a46]">Clinical workspace</div><div className="text-[10px] font-medium text-slate-400">Explainable AI retinal screening</div></div>
          </div>
          <div className="flex items-center gap-2.5">
            <div className="hidden items-center gap-2 rounded-full border border-emerald-100 bg-emerald-50 px-3 py-1.5 text-[10px] font-extrabold text-emerald-700 sm:flex"><span className="ocutrace-status-dot green" /> System ready</div>
            <button className="ocutrace-mode"><Stethoscope size={14} /> Doctor mode</button>
            <button className="rounded-xl p-2 text-slate-400 hover:bg-slate-50" title="Settings"><BarChart3 size={16} /></button>
          </div>
        </header>
        <main className="mx-auto max-w-[1520px] p-4 md:p-6 xl:p-7">{children}</main>
      </div>
    </div>
  );
}
