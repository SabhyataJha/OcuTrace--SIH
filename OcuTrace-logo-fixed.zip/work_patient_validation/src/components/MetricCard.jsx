import React from "react";

export default function MetricCard({ label, value, sub, icon: Icon, tone = "teal" }) {
  const iconClass = {
    teal: "bg-teal-50 text-teal-700",
    blue: "bg-sky-50 text-sky-700",
    amber: "bg-amber-50 text-amber-700",
    rose: "bg-rose-50 text-rose-700",
  }[tone];

  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white p-4 shadow-soft">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-[0.12em] text-slate-400">{label}</div>
          <div className="mt-2 text-2xl font-extrabold tracking-tight text-slate-950">{value}</div>
          <div className="mt-1 text-[11px] font-medium text-slate-400">{sub}</div>
        </div>
        <div className={`grid h-10 w-10 place-items-center rounded-xl ${iconClass}`}>
          <Icon size={18} />
        </div>
      </div>
    </div>
  );
}