import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import NewScreening from "./pages/NewScreening";
import ScreeningStatus from "./pages/ScreeningStatus";
import DoctorReview from "./pages/DoctorReview";
import Queue from "./pages/Queue";
import Report from "./pages/Report";
import Reports from "./pages/Reports";
import Patients from "./pages/Patients";

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/screen/new" element={<NewScreening />} />
        <Route path="/screen/:id" element={<ScreeningStatus />} />
        <Route path="/review/:id" element={<DoctorReview />} />
        <Route path="/queue" element={<Queue />} />
        <Route path="/reports" element={<Reports />} />
        <Route path="/reports/:id" element={<Report />} />
        <Route path="/patients" element={<Patients />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}