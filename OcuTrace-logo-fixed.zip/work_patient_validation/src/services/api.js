import { screeningMock, getQueueScreening, queueScreenings } from "../mockData";

const API_BASE = import.meta.env.VITE_API_BASE_URL || "";
const DEMO_STORAGE_KEY = "retinascope-demo-screenings";
const runtimeScreenings = {};

async function parseResponse(res) {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.detail || "Request failed");
  return data;
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    if (!file) return resolve("");
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Could not read the selected image."));
    reader.readAsDataURL(file);
  });
}

function loadDemoScreenings() {
  try {
    const raw = sessionStorage.getItem(DEMO_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function saveDemoScreening(screening) {
  runtimeScreenings[screening.screeningId] = screening;

  try {
    const all = loadDemoScreenings();
    all[screening.screeningId] = screening;
    const serialized = JSON.stringify(all);
    if (serialized.length < 4_000_000) {
      sessionStorage.setItem(DEMO_STORAGE_KEY, serialized);
    }
  } catch {
    // Runtime storage remains available for the current SPA session.
  }
}

function loadDemoScreening(id) {
  return runtimeScreenings[id] || loadDemoScreenings()[id] || null;
}

/**
 * Returns every screening known to the demo app: built-in queue cases plus
 * screenings created by the user. Dynamic records are merged by screening ID
 * so a newly-created patient immediately becomes visible everywhere.
 */
function getAllDemoScreenings() {
  const saved = loadDemoScreenings();
  const byScreeningId = new Map(queueScreenings.map((item) => [item.screeningId, item]));

  Object.values(saved).forEach((item) => {
    if (item?.screeningId) byScreeningId.set(item.screeningId, item);
  });

  Object.values(runtimeScreenings).forEach((item) => {
    if (item?.screeningId) byScreeningId.set(item.screeningId, item);
  });

  return Array.from(byScreeningId.values());
}

export async function listScreenings() {
  // REAL API:
  // return parseResponse(await fetch(`${API_BASE}/screenings`));
  await new Promise((r) => setTimeout(r, 100));
  return getAllDemoScreenings();
}

export async function createScreening({ patientId, image, patientDetails = {} }) {
  // REAL API:
  // const form = new FormData();
  // form.append("patient_id", patientId);
  // form.append("image", image);
  // return parseResponse(await fetch(`${API_BASE}/screenings`, {
  //   method: "POST", body: form
  // }));

  await new Promise((r) => setTimeout(r, 500));

  const imageDataUrl = await fileToDataUrl(image);
  const screeningId = `DR-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;

  const demoScreening = {
    ...screeningMock,
    screeningId,
    imageUrl: imageDataUrl || screeningMock.imageUrl,
    evidence: {
      ...screeningMock.evidence,
      gradCamUrl: imageDataUrl || screeningMock.evidence.gradCamUrl,
      combinedEvidenceUrl: imageDataUrl || screeningMock.evidence.combinedEvidenceUrl,
    },
    patient: {
      ...screeningMock.patient,
      id: patientId,
      name: patientDetails.name || "Unnamed patient",
      age: Number(patientDetails.age) || null,
      sex: patientDetails.gender || "Not specified",
      diabetesDuration: patientDetails.diabetesDuration || "Not recorded",
      dob: patientDetails.dob || "",
      phone: patientDetails.phone || "",
      emergency: patientDetails.emergency || "",
      address: patientDetails.address || "",
    },
    status: "completed",
    review: null,
  };

  saveDemoScreening(demoScreening);
  return { job_id: screeningId };
}

export async function getScreening(id) {
  // REAL API:
  // return parseResponse(await fetch(`${API_BASE}/screenings/${id}`));

  await new Promise((r) => setTimeout(r, 250));
  const saved = id ? loadDemoScreening(id) : null;
  if (saved) return saved;

  const queued = id ? getQueueScreening(id) : null;
  if (queued) return queued;

  if (!id) return { ...screeningMock };

  return {
    ...screeningMock,
    screeningId: id,
    patient: { ...screeningMock.patient, name: "Unknown patient", id: "—" },
  };
}

export async function submitReview(id, payload) {
  // REAL API:
  // return parseResponse(await fetch(`${API_BASE}/screenings/${id}/review`, {
  //   method: "POST",
  //   headers: { "Content-Type": "application/json" },
  //   body: JSON.stringify(payload),
  // }));

  await new Promise((r) => setTimeout(r, 500));

  const current = loadDemoScreening(id) || getQueueScreening(id) || null;
  const review = {
    ...payload,
    screeningId: id,
    reviewer: "Dr. A. Sharma",
    timestamp: new Date().toISOString(),
  };

  if (current) {
    saveDemoScreening({ ...current, review });
    // Keep every screen in sync immediately when the doctor records a review.
    // Queue/Dashboard listen for this event and refresh their derived counts.
    window.dispatchEvent(new CustomEvent("retinascope:data-changed", {
      detail: { type: "review-recorded", screeningId: id }
    }));
  }

  return { ok: true, review };
}
