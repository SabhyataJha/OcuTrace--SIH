export const screeningMock = {
  screeningId: "DR-2026-00842",
  patient: {
    id: "P-004821",
    name: "Aarav Kumar",
    age: 54,
    sex: "Male",
    diabetesDuration: 8,
    hbA1c: 7.4,
  },
  status: "completed",
  quality: {
    isGradable: true,
    score: 92,
    reasons: [
      { label: "Blur", value: "Good", ok: true },
      { label: "Exposure", value: "Good", ok: true },
      { label: "Field of view", value: "Complete", ok: true },
    ],
  },
  imageUrl:
    "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Fundus_photograph_of_normal_left_eye.jpg/640px-Fundus_photograph_of_normal_left_eye.jpg",
  prediction: {
    grade: 2,
    label: "Moderate NPDR",
    probabilities: [0.02, 0.08, 0.73, 0.14, 0.03],
  },
  evidence: {
    gradCamUrl:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Fundus_photograph_of_normal_left_eye.jpg/640px-Fundus_photograph_of_normal_left_eye.jpg",
    combinedEvidenceUrl:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Fundus_photograph_of_normal_left_eye.jpg/640px-Fundus_photograph_of_normal_left_eye.jpg",
    lesions: [
      { type: "Microaneurysms", count: 14, confidence: 0.87 },
      { type: "Haemorrhages", count: 6, confidence: 0.76 },
    ],
  },
  confidence: {
    calibrated: 0.947,
  },
  decision: {
    referral: "referable",
    rationale: "Grade and calibrated probability crossed the configured referral threshold.",
  },
  review: null,
  timestamps: {
    // Demo data follows the browser's real current date/time instead of a frozen date.
    created: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
  },
};

// Demo queue records share the same shape as a real screening response.
// Keeping them here prevents every unknown queue id from falling back to Aarav Kumar.
const DEMO_FUNDUS =
  "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Fundus_photograph_of_normal_left_eye.jpg/640px-Fundus_photograph_of_normal_left_eye.jpg";

export const queueScreenings = [
  {
    ...screeningMock,
    screeningId: "DR-2026-00842",
    imageUrl: DEMO_FUNDUS,
    evidence: { ...screeningMock.evidence, gradCamUrl: DEMO_FUNDUS, combinedEvidenceUrl: DEMO_FUNDUS },
    patient: { ...screeningMock.patient, id: "P-004821", name: "Aarav Kumar", age: 54, sex: "Male", diabetesDuration: 8, hbA1c: 7.4 },
    prediction: { ...screeningMock.prediction, grade: 2, label: "Moderate NPDR" },
    confidence: { calibrated: 0.947 },
    decision: { referral: "referable", rationale: "Grade and calibrated probability crossed the configured referral threshold." },
    review: null,
    timestamps: { created: new Date(Date.now() - 2 * 60 * 1000).toISOString() }
  },
  {
    ...screeningMock,
    screeningId: "DR-2026-00841",
    imageUrl: DEMO_FUNDUS,
    evidence: { ...screeningMock.evidence, gradCamUrl: DEMO_FUNDUS, combinedEvidenceUrl: DEMO_FUNDUS },
    patient: { ...screeningMock.patient, id: "P-004822", name: "Priya Singh", age: 48, sex: "Female", diabetesDuration: 5, hbA1c: 6.9 },
    prediction: { ...screeningMock.prediction, grade: 1, label: "Mild NPDR", probabilities: [0.05, 0.76, 0.12, 0.05, 0.02] },
    confidence: { calibrated: 0.912 },
    decision: { referral: "routine", rationale: "Findings remain below the configured referral threshold." },
    review: null,
    timestamps: { created: new Date(Date.now() - 17 * 60 * 1000).toISOString() }
  },
  {
    ...screeningMock,
    screeningId: "DR-2026-00840",
    imageUrl: DEMO_FUNDUS,
    evidence: { ...screeningMock.evidence, gradCamUrl: DEMO_FUNDUS, combinedEvidenceUrl: DEMO_FUNDUS },
    patient: { ...screeningMock.patient, id: "P-004823", name: "Rahul Sharma", age: 61, sex: "Male", diabetesDuration: 12, hbA1c: 8.2 },
    prediction: { ...screeningMock.prediction, grade: 3, label: "Severe NPDR", probabilities: [0.01, 0.02, 0.08, 0.86, 0.03] },
    evidence: {
      ...screeningMock.evidence,
      lesions: [
        { type: "Haemorrhages", count: 18, confidence: 0.91 },
        { type: "Microaneurysms", count: 23, confidence: 0.88 },
      ],
      gradCamUrl: DEMO_FUNDUS,
      combinedEvidenceUrl: DEMO_FUNDUS,
    },
    confidence: { calibrated: 0.971 },
    decision: { referral: "referable", rationale: "Severe NPDR probability crossed the configured referral threshold." },
    review: null,
    timestamps: { created: new Date(Date.now() - 38 * 60 * 1000).toISOString() }
  },
  {
    ...screeningMock,
    screeningId: "DR-2026-00839",
    imageUrl: DEMO_FUNDUS,
    evidence: { ...screeningMock.evidence, gradCamUrl: DEMO_FUNDUS, combinedEvidenceUrl: DEMO_FUNDUS, lesions: [] },
    patient: { ...screeningMock.patient, id: "P-004824", name: "Meena Devi", age: 57, sex: "Female", diabetesDuration: 3, hbA1c: 6.5 },
    prediction: { ...screeningMock.prediction, grade: 0, label: "No DR", probabilities: [0.96, 0.02, 0.01, 0.005, 0.005] },
    confidence: { calibrated: 0.963 },
    decision: { referral: "routine", rationale: "No referable diabetic retinopathy features were detected." },
    review: null,
    timestamps: { created: new Date(Date.now() - 60 * 60 * 1000).toISOString() }
  },
];

export function getQueueScreening(id) {
  return queueScreenings.find((caseItem) => caseItem.screeningId === id) || null;
}
