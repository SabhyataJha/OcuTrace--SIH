import React, { useEffect, useMemo, useState } from "react";
import { Search, UsersRound, LoaderCircle } from "lucide-react";
import { listScreenings } from "../services/api";

function patientRowsFromScreenings(screenings) {
  // Patient Records should be driven by the same screening data as the rest
  // of the app, rather than a hard-coded four-patient array.
  const byPatient = new Map();

  screenings.forEach((screening) => {
    const patient = screening?.patient;
    if (!patient?.id) return;

    const row = {
      id: patient.id,
      name: patient.name || "Unnamed patient",
      age: patient.age ?? "—",
      diabetes: patient.diabetesDuration || "Not recorded",
      grade: screening?.prediction?.grade,
      label: screening?.prediction?.label || "Not available",
      decision: screening?.decision?.referral === "referable" ? "Referable" : "Routine",
      created: screening?.timestamps?.created || "",
      screeningId: screening?.screeningId || "",
    };

    // If the same patient has multiple screenings, keep the latest one.
    const existing = byPatient.get(patient.id);
    if (!existing || new Date(row.created || 0) >= new Date(existing.created || 0)) {
      byPatient.set(patient.id, row);
    }
  });

  return Array.from(byPatient.values()).sort((a, b) =>
    a.name.localeCompare(b.name)
  );
}

export default function Patients() {
  const [screenings, setScreenings] = useState([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);

  async function refreshPatients() {
    setLoading(true);
    try {
      const data = await listScreenings();
      setScreenings(Array.isArray(data) ? data : []);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refreshPatients();

    // A new screening can be created in another browser tab/window. Refresh
    // when the app regains focus so Patient Records doesn't stay stale.
    const onFocus = () => refreshPatients();
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, []);

  const patients = useMemo(() => patientRowsFromScreenings(screenings), [screenings]);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return patients;
    return patients.filter((p) =>
      [p.id, p.name, p.screeningId].some((value) => String(value).toLowerCase().includes(q))
    );
  }, [patients, query]);

  return (
    <div className="space-y-6 fade-in">
      <div>
        <div className="text-[11px] font-bold uppercase tracking-[0.18em] text-teal-700">Patient records</div>
        <h1 className="mt-2 text-2xl font-extrabold tracking-tight">Patients</h1>
        <p className="mt-2 text-sm text-slate-500">A lightweight screening history view for the MVP.</p>
      </div>

      <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white px-4 shadow-soft">
        <Search size={16} className="text-slate-400" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full py-3 text-xs outline-none"
          placeholder="Search patient ID or name"
        />
      </div>

      <div className="overflow-x-auto rounded-2xl border border-slate-200/80 bg-white shadow-soft scrollbar-thin">
        <table className="min-w-full text-left">
          <thead className="bg-slate-50">
            <tr className="text-[10px] uppercase tracking-[0.14em] text-slate-400">
              <th className="px-5 py-3">Patient</th>
              <th className="px-5 py-3">Age</th>
              <th className="px-5 py-3">Diabetes</th>
              <th className="px-5 py-3">Latest grade</th>
              <th className="px-5 py-3">Decision</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="5" className="px-5 py-10 text-center text-xs text-slate-400">
                  <LoaderCircle size={16} className="mr-2 inline animate-spin" /> Loading patient records…
                </td>
              </tr>
            ) : filtered.length ? (
              filtered.map((p) => (
                <tr key={p.id} className="border-t border-slate-100">
                  <td className="px-5 py-4">
                    <div className="text-xs font-bold">{p.name}</div>
                    <div className="mt-1 text-[10px] text-slate-400">{p.id}</div>
                  </td>
                  <td className="px-5 py-4 text-xs">{p.age}</td>
                  <td className="px-5 py-4 text-xs text-slate-500">{p.diabetes}</td>
                  <td className="px-5 py-4 text-xs font-bold">
                    {p.grade !== undefined ? `Grade ${p.grade}` : p.label}
                  </td>
                  <td className="px-5 py-4">
                    <span className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${p.decision === "Referable" ? "bg-rose-50 text-rose-700" : "bg-emerald-50 text-emerald-700"}`}>
                      {p.decision}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="px-5 py-10 text-center text-xs text-slate-400">
                  No patient records found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center gap-2 text-[11px] text-slate-400">
        <UsersRound size={14} /> Patient history is synced from screening records.
      </div>
    </div>
  );
}
