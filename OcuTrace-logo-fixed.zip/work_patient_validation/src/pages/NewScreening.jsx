import React, { useRef, useState } from "react";
import {
  ArrowRight, CalendarDays, Camera, CheckCircle2, Droplets, FileImage,
  HeartPulse, MapPin, Phone, UserRound, Upload, X, ShieldCheck, Sparkles,
  AlertTriangle, Check, LoaderCircle, EyeOff, SunMedium, ScanFace
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createScreening } from "../services/api";

const fields = [
  ["id", "Patient ID", "P-004821", UserRound],
  ["name", "Full name", "Patient name", UserRound],
  ["dob", "Date of birth", "DD / MM / YYYY", CalendarDays],
  ["gender", "Gender", "Select gender", UserRound],
  ["phone", "Phone number", "10 digit number", Phone],
  ["emergency", "Emergency contact", "10 digit number", HeartPulse],
  ["address", "Address", "Village / town, district", MapPin],
  ["diabetesDuration", "Diabetes duration", "e.g. 8 years", Droplets],
];

function validatePatient(patient) {
  const errors = {};
  const name = patient.name.trim();
  const address = patient.address.trim();
  const diabetes = patient.diabetesDuration.trim();

  if (!/^P-\d{6}$/.test(patient.id.trim())) errors.id = "Invalid entry. Use the format P-004821 (P- followed by 6 digits).";
  if (!/^[A-Za-z]+(?:[\s][A-Za-z]+)*$/.test(name)) errors.name = "Invalid entry. Full name can contain alphabetic characters and spaces only.";
  if (!/^\d{2}\s*\/\s*\d{2}\s*\/\s*\d{4}$/.test(patient.dob.trim())) {
    errors.dob = "Invalid entry. Use DD / MM / YYYY.";
  } else {
    const parts = patient.dob.trim().split(/\s*\/\s*/);
    const day = Number(parts[0]), month = Number(parts[1]), year = Number(parts[2]);
    const date = new Date(year, month - 1, day);
    const validDate = date.getFullYear() === year && date.getMonth() === month - 1 && date.getDate() === day;
    const today = new Date(); today.setHours(23,59,59,999);
    if (!validDate || date > today) errors.dob = "Invalid entry. Enter a valid date that is not in the future.";
  }
  if (!patient.gender) errors.gender = "Please select a gender.";
  if (!/^\d{10}$/.test(patient.phone.trim())) errors.phone = "Invalid entry. Enter exactly 10 numerical digits.";
  if (!/^\d{10}$/.test(patient.emergency.trim())) errors.emergency = "Invalid entry. Enter exactly 10 numerical digits.";
  if (!address) errors.address = "This field is required.";
  if (!diabetes) errors.diabetesDuration = "This field is required.";

  return errors;
}

export default function NewScreening() {
  const navigate = useNavigate();
  const inputRef = useRef(null);
  const [patient, setPatient] = useState({
    id: "", name: "", dob: "", gender: "",
    phone: "", emergency: "", address: "", diabetesDuration: ""
  });
  const [patientErrors, setPatientErrors] = useState({});
  const [patientTouched, setPatientTouched] = useState({});
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState("");
  const [busy, setBusy] = useState(false);
  const [qualityChecking, setQualityChecking] = useState(false);
  const [qualityResult, setQualityResult] = useState(null);
  const [dragging, setDragging] = useState(false);

  async function selectImage(selected) {
    if (!selected) return;

    // Reset the native input so selecting the same file again still triggers onChange.
    if (inputRef.current) inputRef.current.value = "";
    setQualityResult(null);

    setQualityChecking(true);
    try {
      const result = await analyzeImageQuality(selected);
      if (!result.ok) {
        // A rejected image is never accepted into the screening state.
        if (preview) URL.revokeObjectURL(preview);
        setPreview("");
        setFile(null);
        setQualityResult(result);
        return;
      }

      if (preview) URL.revokeObjectURL(preview);
      setFile(selected);
      setPreview(URL.createObjectURL(selected));
      setQualityResult({ ...result, accepted: true });
    } catch (error) {
      setFile(null);
      if (preview) URL.revokeObjectURL(preview);
      setPreview("");
      setQualityResult({
        ok: false,
        reasons: [error?.message || "The image could not be validated. Please upload a retinal/fundus photograph."],
        checks: [],
      });
    } finally {
      setQualityChecking(false);
    }
  }

  function pick(e) { selectImage(e.target.files?.[0]); }

  function drop(e) {
    e.preventDefault();
    setDragging(false);
    selectImage(e.dataTransfer.files?.[0]);
  }

  function removeImage() {
    if (preview) URL.revokeObjectURL(preview);
    setPreview("");
    setFile(null);
    setQualityResult(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  async function analyzeImageQuality(selectedFile) {
    const reasons = [];
    const checks = [];

    if (!selectedFile) {
      return { ok: false, reasons: ["No image was selected. Upload a fundus image first."], checks: [] };
    }

    if (!selectedFile.type?.startsWith("image/")) {
      return { ok: false, reasons: ["The selected file is not a supported image. Please upload a JPG, JPEG, or PNG fundus image."], checks: [] };
    }

    if (selectedFile.size > 15 * 1024 * 1024) {
      reasons.push("The image file is unusually large (over 15 MB). Please upload a standard compressed retinal image.");
    }

    let width = 0;
    let height = 0;
    let image;

    try {
      image = await new Promise((resolve, reject) => {
        const src = URL.createObjectURL(selectedFile);
        const img = new Image();
        img.onload = () => {
          URL.revokeObjectURL(src);
          resolve(img);
        };
        img.onerror = () => {
          URL.revokeObjectURL(src);
          reject(new Error("The image could not be decoded."));
        };
        img.src = src;
      });
    } catch {
      return {
        ok: false,
        reasons: ["The image could not be read. It may be corrupted or in an unsupported format."],
        checks: [],
      };
    }

    width = image.naturalWidth || image.width;
    height = image.naturalHeight || image.height;

    // Resolution is informational only in demo mode. Do not reject an image based on pixel dimensions.
    const megapixels = (width * height) / 1_000_000;

    const ratio = width / height;
    const framingOk = ratio >= 0.65 && ratio <= 1.55 && megapixels >= 0.3;
    checks.push({ key: "framing", label: "Field of view", value: framingOk ? "Complete" : "Check framing", ok: framingOk, icon: ScanFace });
    if (!framingOk) {
      reasons.push("The image framing does not look like a complete retinal field. Use a centered fundus image with the full circular field visible.");
    }

    const canvas = document.createElement("canvas");
    const sampleSize = 256;
    canvas.width = sampleSize;
    canvas.height = sampleSize;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(image, 0, 0, sampleSize, sampleSize);
    const { data } = ctx.getImageData(0, 0, sampleSize, sampleSize);

    let luminanceSum = 0;
    let contentCount = 0;
    const gray = new Float32Array(sampleSize * sampleSize);
    for (let i = 0, p = 0; i < data.length; i += 4, p += 1) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const y = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      gray[p] = y;
      luminanceSum += y;
      if (r + g + b > 35) contentCount += 1;
    }

    const mean = luminanceSum / gray.length;
    const contentRatio = contentCount / gray.length;

    // Fundus/non-fundus safeguard. This deliberately looks for the visual
    // signature of a retinal photograph: a warm red/orange central retinal
    // field, red-channel dominance and a roughly circular/elliptical field.
    // It is a frontend screening safeguard, not a clinical classifier.
    let centralCount = 0;
    let warmCentralCount = 0;
    let redDominantCount = 0;
    let edgeDarkCount = 0;
    let centralRedSum = 0;
    let centralGreenSum = 0;
    let centralBlueSum = 0;

    for (let y = 0; y < sampleSize; y++) {
      for (let x = 0; x < sampleSize; x++) {
        const dx = (x - (sampleSize - 1) / 2) / ((sampleSize - 1) / 2);
        const dy = (y - (sampleSize - 1) / 2) / ((sampleSize - 1) / 2);
        const radius = Math.sqrt(dx * dx + dy * dy);
        const idx = (y * sampleSize + x) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];

        if (radius <= 0.78) {
          centralCount += 1;
          centralRedSum += r;
          centralGreenSum += g;
          centralBlueSum += b;
          if (r > g * 1.08 && r > b * 1.12 && r > 45) warmCentralCount += 1;
          if (r > g * 1.03 && r > b * 1.08) redDominantCount += 1;
        }
        if (radius >= 0.88 && (r + g + b) / 3 < 70) edgeDarkCount += 1;
      }
    }

    const warmCentralRatio = warmCentralCount / Math.max(1, centralCount);
    const redDominanceRatio = (centralRedSum / Math.max(1, centralCount)) /
      (((centralGreenSum + centralBlueSum) / Math.max(1, centralCount)) / 2 + 1);
    const redDominantRatio = redDominantCount / Math.max(1, centralCount);
    const edgeDarkRatio = edgeDarkCount / Math.max(1, sampleSize * sampleSize - centralCount);

    const fundusColorOk = warmCentralRatio >= 0.30 && redDominanceRatio >= 1.05 && redDominantRatio >= 0.30;
    const fundusFieldOk = edgeDarkRatio >= 0.03 || warmCentralRatio >= 0.48;
    const fundusDetected = fundusColorOk && fundusFieldOk;

    checks.push({
      key: "fundus",
      label: "Retinal image",
      value: fundusDetected ? "Fundus detected" : "Not a fundus image",
      ok: fundusDetected,
      icon: ScanFace,
    });

    if (!fundusDetected) {
      reasons.push("This image does not look like a retinal/fundus photograph. Upload a centered fundus image showing the circular retinal field, optic disc and retinal vessels.");
    }
    const exposureOk = mean >= 28 && mean <= 225;
    checks.push({ key: "exposure", label: "Exposure", value: exposureOk ? "Balanced" : mean < 28 ? "Too dark" : "Washed out", ok: exposureOk, icon: SunMedium });
    if (!exposureOk) {
      reasons.push(mean < 28
        ? "The image is too dark. Increase illumination and capture the retina again."
        : "The image is overexposed or washed out. Reduce glare/illumination and recapture.");
    }

    // Approximate blur detection using variance of the Laplacian on a 256×256 preview.
    let lapSum = 0;
    let lapSqSum = 0;
    let lapCount = 0;
    for (let y = 1; y < sampleSize - 1; y += 2) {
      for (let x = 1; x < sampleSize - 1; x += 2) {
        const idx = y * sampleSize + x;
        const lap = gray[idx - 1] + gray[idx + 1] + gray[idx - sampleSize] + gray[idx + sampleSize] - 4 * gray[idx];
        lapSum += lap;
        lapSqSum += lap * lap;
        lapCount += 1;
      }
    }
    const lapMean = lapSum / lapCount;
    const lapVariance = Math.max(0, lapSqSum / lapCount - lapMean * lapMean);
    const sharpnessOk = lapVariance >= 30;
    checks.push({ key: "focus", label: "Focus", value: sharpnessOk ? "Sharp enough" : "Too blurry", ok: sharpnessOk, icon: EyeOff });
    if (!sharpnessOk) {
      reasons.push(`The retinal image appears blurry (focus score ${Math.round(lapVariance)}). Keep the camera steady and recapture with the retina in focus.`);
    }

    const fieldContentOk = contentRatio >= 0.20;
    if (!fieldContentOk) {
      reasons.push("The visible retinal field is too limited or the image contains excessive empty/black area. Recenter the retina and capture again.");
    }

    const ok = fundusDetected && reasons.length === 0;
    return {
      ok,
      fundusDetected,
      reasons,
      checks,
      metrics: {
        width,
        height,
        mean: Math.round(mean),
        lapVariance: Math.round(lapVariance),
        warmCentralRatio: Number(warmCentralRatio.toFixed(2)),
        redDominanceRatio: Number(redDominanceRatio.toFixed(2)),
      },
    };
  }

  function updatePatient(key, value) {
    setPatient((prev) => ({ ...prev, [key]: value }));
    setPatientTouched((prev) => ({ ...prev, [key]: true }));
    setPatientErrors((prev) => {
      const nextPatient = { ...patient, [key]: value };
      const nextErrors = validatePatient(nextPatient);
      const next = { ...prev };
      if (nextErrors[key]) next[key] = nextErrors[key];
      else delete next[key];
      return next;
    });
  }

  async function runQualityCheck() {
    const errors = validatePatient(patient);
    setPatientErrors(errors);
    setPatientTouched(Object.fromEntries(Object.keys(patient).map((key) => [key, true])));
    if (Object.keys(errors).length > 0) return;

    if (!file) {
      setQualityResult({
        ok: false,
        reasons: ["No image was selected. Upload a fundus image first."],
        checks: [],
      });
      return;
    }

    setQualityChecking(true);
    setQualityResult(null);
    try {
      const result = await analyzeImageQuality(file);
      if (!result.ok) {
        setQualityResult(result);
        return;
      }

      if (!patient.id || !patient.name) {
        setQualityResult({
          ...result,
          ok: true,
          accepted: true,
          patientIncomplete: true,
        });
        return;
      }

      setBusy(true);
      const screening = await createScreening({
        patientId: patient.id,
        image: file,
        patientDetails: patient,
      });
      navigate(`/screen/${screening.job_id}`);
    } catch (error) {
      setQualityResult({
        ok: false,
        reasons: [error?.message || "Quality check failed unexpectedly. Please try the image again."],
        checks: [],
      });
    } finally {
      setQualityChecking(false);
      setBusy(false);
    }
  }


  return (
    <div className="mx-auto max-w-6xl space-y-6 fade-in">
      <section className="rs-medical-grid relative overflow-hidden rounded-[30px] border border-[#dce6ef] bg-white px-6 py-6 shadow-soft md:px-8">
        <div className="absolute -right-16 -top-20 h-52 w-52 rounded-full bg-[#e7f7f5]" />
        <div className="absolute -bottom-28 left-1/3 h-52 w-52 rounded-full bg-[#edf4fb]" />
        <div className="relative flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <h1 className="text-[28px] font-extrabold tracking-tight text-[#10243e] md:text-[34px]">Create a retinal screening</h1>
            <p className="mt-2 max-w-2xl text-[13px] leading-6 text-[#6f8299]">
              Register the patient, attach a fundus image, and validate the image as a retinal photograph before it enters the AI screening workflow.
            </p>
          </div>
          <div className="flex items-center gap-2 rounded-2xl border border-[#cfe7e3] bg-white/80 px-4 py-3">
            <ShieldCheck size={17} className="text-[#118f87]" />
            <div>
              <div className="text-[11px] font-bold text-[#294760]">Clinical workflow</div>
              <div className="text-[10px] text-[#8294a7]">Quality first · human review later</div>
            </div>
          </div>
        </div>
      </section>

      <form onSubmit={(e) => e.preventDefault()} className="grid gap-6 xl:grid-cols-[.82fr_1.18fr]">
        <section className="overflow-hidden rounded-[28px] border border-[#dce6ef] bg-white shadow-soft rs-lift">
          <div className="relative overflow-hidden bg-gradient-to-br from-[#123e63] via-[#155e75] to-[#118f87] px-6 py-6 text-white">
            <div className="absolute -right-16 -top-16 h-52 w-52 rounded-full border border-white/10" />
            <div className="absolute -bottom-24 right-8 h-48 w-48 rounded-full border border-white/10" />
            <div className="relative">
              <div className="flex items-center gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-white/10 ring-1 ring-white/15">
                  <HeartPulse size={19} />
                </div>
                <div>
                  <div className="text-xl font-extrabold">Patient details</div>
                  <div className="mt-0.5 text-[11px] text-white/65">Clinical context for this screening</div>
                </div>
              </div>
              <p className="mt-3 max-w-sm text-[12px] leading-5 text-white/65">
                A compact clinical record keeps the screening fast and gives the reviewer the context needed for safe review.
              </p>
            </div>
          </div>

          <div className="-mt-6 relative z-10 mx-4 rounded-2xl border border-[#dce6ef] bg-white p-5 shadow-[0_12px_40px_rgba(16,36,62,.06)] md:mx-5">
            <div className="grid gap-4 sm:grid-cols-2">
              {fields.map(([key, label, placeholder, Icon]) => (
                <label key={key} className={key === "address" ? "sm:col-span-2" : ""}>
                  <span className="mb-1.5 flex items-center justify-between text-[11px] font-bold text-[#36506a]">
                    <span>{label}</span><span className="text-[#118f87]">*</span>
                  </span>
                  <div className="relative">
                    <Icon size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#7d95aa]" />
                    {key === "gender" ? (
                      <select value={patient[key]} onChange={(e) => updatePatient(key, e.target.value)}
                        className={["w-full rounded-xl border bg-[#f7fafc] py-3 pl-9 pr-3 text-[12px] font-bold text-[#243e58] outline-none focus:border-[#2a9f97] focus:bg-white focus:ring-4 focus:ring-[#118f87]/10", patientTouched[key] && patientErrors[key] ? "border-rose-300 bg-rose-50/40" : "border-[#d4e0ea]"].join(" ")}>
                        <option value="">Select gender</option><option>Male</option><option>Female</option><option>Other</option><option>Prefer not to say</option>
                      </select>
                    ) : (
                      <input value={patient[key]} onChange={(e) => updatePatient(key, e.target.value)}
                        placeholder={placeholder}
                        inputMode={(key === "phone" || key === "emergency") ? "numeric" : key === "dob" ? "numeric" : undefined}
                        className={["w-full rounded-xl border bg-[#f7fafc] py-3 pl-9 pr-3 text-[12px] font-bold text-[#243e58] placeholder:text-[#9aacbc] outline-none focus:border-[#2a9f97] focus:bg-white focus:ring-4 focus:ring-[#118f87]/10", patientTouched[key] && patientErrors[key] ? "border-rose-300 bg-rose-50/40" : "border-[#d4e0ea]"].join(" ")} />
                    )}
                  </div>
                  {patientTouched[key] && patientErrors[key] && (
                    <div className="mt-1.5 text-[10px] font-bold text-rose-600">{patientErrors[key]}</div>
                  )}
                </label>
              ))}
            </div>

          </div>
        </section>

        <section className="overflow-hidden rounded-[28px] border border-[#dce6ef] bg-white p-5 shadow-soft rs-lift md:p-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-[14px] font-extrabold text-[#10243e]">
                <FileImage size={18} className="text-[#118f87]" /> Fundus image
              </div>
              <div className="mt-1 text-[12px] text-[#74889c]">Only genuine retinal/fundus photographs are accepted. The image is validated before screening.</div>
            </div>
            {preview && (
              <button type="button" onClick={removeImage} className="rounded-xl border border-[#dce6ef] px-3 py-2 text-[11px] font-bold text-[#60758b] hover:bg-[#f6f9fb]">
                <X size={13} className="mr-1 inline" /> Remove
              </button>
            )}
          </div>

          <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={pick} />

          {preview ? (
            <div className="mt-5 overflow-hidden rounded-[24px] border border-[#17334d] bg-[#071522]">
              <div className="relative flex min-h-[430px] items-center justify-center p-5">
                <div className="absolute inset-0 opacity-[.065]" style={{backgroundImage:"linear-gradient(rgba(255,255,255,.8) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.8) 1px,transparent 1px)",backgroundSize:"28px 28px"}} />
                <div className="relative max-h-[420px] max-w-full overflow-hidden rounded-full ring-2 ring-[#9fe5df]/35 shadow-[0_24px_90px_rgba(0,0,0,.48)]">
                  <img src={preview} alt="Selected fundus image" className="block max-h-[405px] max-w-full object-contain" />
                </div>
                <div className="absolute left-4 top-4 flex items-center gap-2 rounded-full border border-emerald-300/25 bg-emerald-500/15 px-3 py-1.5 text-[10px] font-bold text-emerald-200 backdrop-blur">
                  <CheckCircle2 size={13}/> Image loaded · ready
                </div>
                <button type="button" onClick={() => inputRef.current?.click()} className="absolute bottom-4 right-4 rounded-xl border border-white/10 bg-white/10 px-3 py-2 text-[10px] font-bold text-white backdrop-blur hover:bg-white/15">
                  Replace image
                </button>
              </div>
              <div className="grid gap-2 border-t border-white/10 bg-[#0b1d2d] p-4 sm:grid-cols-[1fr_auto] sm:items-center">
                <div className="min-w-0">
                  <div className="truncate text-[12px] font-bold text-white">{file?.name}</div>
                  <div className="mt-1 text-[10px] text-white/40">Fundus validation passed · image accepted for screening</div>
                </div>
                <div className="rounded-xl bg-white/5 px-3 py-2 text-center text-[10px] font-bold text-white/70">{file ? `${Math.round(file.size / 1024)} KB` : ""}</div>
              </div>
            </div>
          ) : (
            <div
              onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={drop}
              className={[
                "relative mt-5 flex min-h-[430px] w-full flex-col items-center justify-center overflow-hidden rounded-[24px] border-2 border-dashed px-6 text-center transition",
                dragging ? "border-[#118f87] bg-[#eaf8f6]" : "border-[#c8d7e3] bg-[radial-gradient(circle_at_50%_36%,rgba(17,143,135,.10),transparent_31%),linear-gradient(180deg,#fbfdff,#f5f9fc)]",
              ].join(" ")}
            >
              <div className="absolute inset-5 rounded-[19px] border border-white/90" />
              <div className="relative grid h-20 w-20 place-items-center rounded-[26px] bg-white text-[#35536e] shadow-[0_15px_45px_rgba(16,36,62,.10)]">
                <Upload size={30} strokeWidth={1.7} />
              </div>
              <div className="relative mt-6 text-xl font-extrabold text-[#10243e]">Drop a fundus image here</div>
              <div className="relative mt-2 max-w-md text-[11px] leading-5 text-[#74889c]">
                Choose a retinal image from the device or capture one using the local camera workflow.
              </div>
              <div className="relative mt-6 flex flex-wrap justify-center gap-2">
                <button type="button" onClick={() => inputRef.current?.click()} className="rounded-xl border border-[#cad8e5] bg-white px-4 py-2.5 text-[11px] font-bold text-[#294760] shadow-sm hover:border-[#88c7c2] hover:text-[#0f706b]">
                  <Upload size={14} className="mr-1.5 inline" /> Choose image
                </button>
                <button type="button" onClick={() => inputRef.current?.click()} className="rounded-xl border border-[#cad8e5] bg-white px-4 py-2.5 text-[11px] font-bold text-[#294760] shadow-sm hover:border-[#88c7c2] hover:text-[#0f706b]">
                  <Camera size={14} className="mr-1.5 inline" /> Capture
                </button>
              </div>
              <div className="relative mt-5 text-[10px] font-semibold text-[#9aabbc]">JPG / PNG · drag & drop supported</div>
            </div>
          )}

          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            {[["01","FOCUS","Avoid motion blur"],["02","EXPOSURE","Avoid dark or washed-out images"],["03","FIELD OF VIEW","Keep the retinal field complete"]].map(([n,a,b]) => (
              <div key={a} className="rounded-2xl border border-[#e1e9f0] bg-[#f8fbfd] p-3.5">
                <div className="flex items-center justify-between"><span className="text-[9px] font-bold text-[#118f87]">{n}</span><span className="text-[9px] font-extrabold tracking-[0.12em] text-[#627990]">{a}</span></div>
                <div className="mt-2 text-[10px] font-semibold leading-4 text-[#8a9bad]">{b}</div>
              </div>
            ))}
          </div>

          <div className="mt-4 flex items-start gap-2 rounded-2xl border border-amber-100 bg-amber-50 p-3.5 text-[10px] leading-5 text-amber-800">
            <ArrowRight size={13} className="mt-0.5 shrink-0" />
            Non-retinal images are rejected and cannot proceed to DR screening.
          </div>

          <button type="button" onClick={runQualityCheck} disabled={!file || busy || qualityChecking}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#123e63] via-[#155e75] to-[#118f87] px-4 py-4 text-[13px] font-extrabold text-white shadow-[0_14px_30px_rgba(17,56,95,.20)] transition hover:-translate-y-0.5 hover:shadow-[0_18px_38px_rgba(17,56,95,.28)] disabled:cursor-not-allowed disabled:opacity-35">
            {qualityChecking ? <><LoaderCircle className="animate-spin" size={16} /> Validating retinal image...</> : busy ? <>Creating screening...</> : <>Validate image & start screening <ArrowRight size={16} /></>}
          </button>

          {qualityResult?.ok && (
            <div className="mt-3 flex items-start gap-2 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-[11px] font-bold text-emerald-700 fade-in">
              <CheckCircle2 size={15} className="mt-0.5 shrink-0" />
              <span>Fundus image validated · ready for screening.{qualityResult.patientIncomplete ? " Complete all required patient details to create the screening." : ""}</span>
            </div>
          )}
        </section>
      </form>


      {qualityResult && !qualityResult.ok && (
        <div className="rs-modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="fundus-validation-title">
          <div className="rs-quality-modal fade-in">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-amber-50 text-amber-700 ring-1 ring-amber-100">
                  <AlertTriangle size={21} />
                </div>
                <div>
                  <div id="fundus-validation-title" className="text-[18px] font-extrabold text-[#10243e]">Fundus image validation failed</div>
                  <div className="mt-1 text-[11px] leading-5 text-[#72869a]">This image was not accepted as a retinal/fundus photograph. Upload a genuine fundus image to continue.</div>
                </div>
              </div>
              <button type="button" onClick={() => setQualityResult(null)} className="grid h-8 w-8 place-items-center rounded-xl text-[#7b8da0] hover:bg-[#f4f7fa] hover:text-[#243e58]" aria-label="Close quality warning">
                <X size={17} />
              </button>
            </div>

            <div className="mt-5 rounded-2xl border border-amber-100 bg-amber-50/70 p-4">
              <div className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-amber-800">Why the image was rejected</div>
              <div className="mt-3 space-y-2.5">
                {qualityResult.reasons.map((reason) => (
                  <div key={reason} className="flex items-start gap-2.5 text-[12px] font-semibold leading-5 text-[#5f4a16]">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-amber-500" />
                    <span>{reason}</span>
                  </div>
                ))}
              </div>
            </div>

            {qualityResult.checks?.length > 0 && (
              <div className="mt-4 grid gap-2 sm:grid-cols-2">
                {qualityResult.checks.map(({ key, label, value, ok, icon: Icon }) => (
                  <div key={key} className={['rs-quality-check', ok ? 'is-good' : 'is-bad'].join(' ')}>
                    <div className="grid h-8 w-8 place-items-center rounded-xl bg-white shadow-sm">
                      <Icon size={15} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-[#708399]">{label}</div>
                      <div className="mt-0.5 truncate text-[11px] font-bold text-[#243e58]">{value}</div>
                    </div>
                    <div className="grid h-6 w-6 place-items-center rounded-full bg-white">{ok ? <Check size={13} /> : <X size={13} />}</div>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-5 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
              <button type="button" onClick={() => setQualityResult(null)} className="rounded-xl border border-[#d5e0e9] bg-white px-4 py-2.5 text-[11px] font-bold text-[#34516c] hover:border-[#9ab4ca] hover:bg-[#f8fbfd]">Review image</button>
              <button type="button" onClick={() => { setQualityResult(null); inputRef.current?.click(); }} className="inline-flex items-center justify-center gap-2 rounded-xl bg-[#123e63] px-4 py-2.5 text-[11px] font-extrabold text-white shadow-sm hover:bg-[#0e3556]">
                <Upload size={14} /> Upload another image
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
