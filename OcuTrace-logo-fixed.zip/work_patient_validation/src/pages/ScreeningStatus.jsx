import React, { useEffect, useMemo, useState } from "react";
import { ArrowRight, Check, CircleDot, FileWarning, LoaderCircle, ScanLine } from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { getScreening } from "../services/api";
import StatusBadge from "../components/StatusBadge";

const steps = [
  ["quality", "Image quality check", "Blur, exposure and field of view"],
  ["enhancement", "Image enhancement", "Resize and normalize"],
  ["classification", "DR classification", "Grade 0–4"],
  ["evidence", "Evidence generation", "Grad-CAM and lesion evidence"],
  ["decision", "Confidence & decision", "Calibration and referral rule"],
];

export default function ScreeningStatus() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    let mounted = true;
    getScreening(id).then((result) => {
      if (mounted) setData(result);
    });
    return () => { mounted = false; };
  }, [id]);

  useEffect(() => {
    if (!data) return;

    // MOCK/DEMO MODE:
    // Simulates the pipeline so the frontend does not appear stuck.
    // With Person 5's real FastAPI backend, replace this timer logic
    // with the status returned by GET /screenings/{id}.
    const interval = window.setInterval(() => {
      setStepIndex((current) => {
        if (current >= steps.length) {
          window.clearInterval(interval);
          return current;
        }
        return current + 1;
      });
    }, 850);

    const redirectTimer = window.setTimeout(() => {
      navigate(`/review/${id}`);
    }, 850 * (steps.length + 1.5));

    return () => {
      window.clearInterval(interval);
      window.clearTimeout(redirectTimer);
    };
  }, [data, id, navigate]);

  const pipelineState = useMemo(
    () =>
      steps.map((_, index) =>
        stepIndex > index ? "complete" : stepIndex === index ? "running" : "queued"
      ),
    [stepIndex]
  );

  if (!data) {
    return (
      <div className="mx-auto max-w-3xl rounded-2xl border border-slate-200 bg-white p-10 shadow-soft">
        <div className="shimmer h-5 w-44 rounded" />
        <div className="mt-4 shimmer h-4 w-full rounded" />
      </div>
    );
  }

  const complete = stepIndex >= steps.length;
  const progress = complete
    ? 100
    : Math.min(Math.round((stepIndex / steps.length) * 100 + 8), 96);

  return (
    <div className="mx-auto max-w-4xl space-y-6 fade-in">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-[0.18em] text-teal-700">
            Processing
          </div>
          <h1 className="mt-2 text-2xl font-extrabold tracking-tight">
            {complete ? "Analysis complete" : "Screening in progress"}
          </h1>
          <p className="mt-2 text-sm text-slate-500">
            {complete
              ? "All screening stages have completed. Opening the doctor review workspace..."
              : "The screening pipeline is progressing through each stage."}
          </p>
        </div>

        <StatusBadge tone={complete ? "good" : "info"}>
          {complete ? "Analysis complete" : "AI pipeline running"}
        </StatusBadge>
      </div>

      <section className="rounded-2xl border border-slate-200/80 bg-white p-6 shadow-soft">
        <div className="flex items-center gap-3 border-b border-slate-100 pb-5">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-teal-50 text-teal-700">
            <ScanLine size={20} />
          </div>
          <div>
            <div className="text-sm font-bold">{data.patient.name}</div>
            <div className="mt-1 text-[11px] text-slate-400">
              {data.screeningId} · {data.patient.age} years
            </div>
          </div>
        </div>

        <div className="mt-7 space-y-2">
          {steps.map(([key, title, body], idx) => {
            const state = pipelineState[idx];

            return (
              <div
                key={key}
                className={[
                  "flex gap-4 rounded-2xl px-3 py-4 transition-all duration-300",
                  state === "running" ? "bg-teal-50/50" : "",
                ].join(" ")}
              >
                <div
                  className={[
                    "mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full transition",
                    state === "complete"
                      ? "bg-emerald-50 text-emerald-600"
                      : state === "running"
                      ? "bg-teal-50 text-teal-700"
                      : "bg-slate-100 text-slate-400",
                  ].join(" ")}
                >
                  {state === "complete" ? (
                    <Check size={17} />
                  ) : state === "running" ? (
                    <LoaderCircle className="animate-spin" size={17} />
                  ) : (
                    <CircleDot size={17} />
                  )}
                </div>

                <div className="flex-1">
                  <div className="text-xs font-bold text-slate-900">{title}</div>
                  <div className="mt-1 text-[11px] text-slate-400">{body}</div>
                </div>

                <div className="self-center text-[10px] font-bold">
                  {state === "complete" ? (
                    <span className="text-emerald-600">Complete</span>
                  ) : state === "running" ? (
                    <span className="text-teal-700">Running</span>
                  ) : (
                    <span className="text-slate-400">Queued</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 overflow-hidden rounded-2xl bg-slate-950 p-4 text-white">
          <div className="flex items-center justify-between text-[10px] font-bold">
            <span>{complete ? "Pipeline complete" : "Pipeline progress"}</span>
            <span className="text-teal-300">{progress}%</span>
          </div>

          <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-teal-400 transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>

          <div className="mt-3 text-[10px] text-white/50">
            Quality → enhancement → classifier → evidence → calibrated decision
          </div>
        </div>

        <div className="mt-5 grid gap-3 md:grid-cols-2">
          <div className="rounded-xl bg-slate-50 p-3 text-[10px] text-slate-500">
            <span className="font-bold text-slate-800">Quality gate:</span>{" "}
            accepted image · {data.quality.score}/100
          </div>
          <div className="rounded-xl bg-slate-50 p-3 text-[10px] text-slate-500">
            <span className="font-bold text-slate-800">Next:</span>{" "}
            {complete ? "Doctor review" : steps[Math.min(stepIndex, steps.length - 1)][1]}
          </div>
        </div>
      </section>

      <div className="flex items-start gap-3 rounded-2xl border border-slate-200 bg-white p-4 text-[11px] leading-5 text-slate-500 shadow-soft">
        <FileWarning size={16} className="mt-0.5 shrink-0 text-slate-400" />
        <div>
          <span className="font-bold text-slate-700">Safety boundary:</span>{" "}
          the application is a screening aid. Final clinical interpretation remains with the ophthalmologist.
        </div>
      </div>

      <div className="flex justify-end">
        <Link
          to={`/review/${id}`}
          className="inline-flex items-center gap-2 rounded-xl bg-slate-950 px-4 py-3 text-xs font-bold text-white"
        >
          {complete ? "Open doctor review" : "Skip to review"}
          <ArrowRight size={15} />
        </Link>
      </div>
    </div>
  );
}
