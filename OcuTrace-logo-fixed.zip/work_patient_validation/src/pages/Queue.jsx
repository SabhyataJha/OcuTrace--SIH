import React, { useCallback, useEffect, useMemo, useState } from "react";
import { ArrowRight, CalendarDays, Clock3, Filter, Search, Stethoscope, UserRound } from "lucide-react";
import { Link } from "react-router-dom";
import StatusBadge from "../components/StatusBadge";
import { listScreenings } from "../services/api";

function sameLocalDay(a, b) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

function queueRowsFromScreenings(screenings) {
  const now = new Date();
  return screenings.map((s) => {
    const created = s?.timestamps?.created ? new Date(s.timestamps.created) : null;
    const dateLabel = created && sameLocalDay(created, now)
      ? "TODAY"
      : created?.toLocaleDateString("en-IN", { weekday: "short" }).toUpperCase() || "—";

    return ({
    id: s.screeningId,
    name: s?.patient?.name || "Unnamed patient",
    day: created ? created.getDate() : "—",
    month: created ? created.toLocaleString("en-US", { month: "short" }).toUpperCase() : "—",
    week: dateLabel,
    time: created ? created.toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" }) : "—",
    type: s?.type || "DR Screening",
    result: `Grade ${s?.prediction?.grade ?? "—"} · ${s?.prediction?.label || "Result pending"}`,
    confidence: s?.confidence?.calibrated != null ? `${(s.confidence.calibrated * 100).toFixed(1)}%` : "—",
    decision: s?.decision?.referral === "referable" ? "Referable" : "Routine",
    tone: s?.decision?.referral === "referable" ? "danger" : "good",
    reviewed: Boolean(s?.review),
    created: s?.timestamps?.created || "",
  });
  }).sort((a, b) => new Date(a.created || 0) - new Date(b.created || 0));
}

export default function Queue() {
  const [tab, setTab] = useState("Upcoming");
  const [query, setQuery] = useState("");
  const [screenings, setScreenings] = useState([]);

  const refresh = useCallback(async () => {
    const data = await listScreenings();
    setScreenings(Array.isArray(data) ? data : []);
  }, []);

  useEffect(() => {
    refresh();
    const onChanged = () => refresh();
    const onFocus = () => refresh();
    window.addEventListener("retinascope:data-changed", onChanged);
    window.addEventListener("focus", onFocus);
    return () => {
      window.removeEventListener("retinascope:data-changed", onChanged);
      window.removeEventListener("focus", onFocus);
    };
  }, [refresh]);

  const allRows = useMemo(() => queueRowsFromScreenings(screenings), [screenings]);
  const pendingRows = useMemo(() => allRows.filter((x) => !x.reviewed), [allRows]);
  const pastRows = useMemo(() => allRows.filter((x) => x.reviewed), [allRows]);
  const sourceRows = tab === "Upcoming" ? pendingRows : pastRows;
  const visible = useMemo(() => {
    const q = query.toLowerCase().trim();
    return q ? sourceRows.filter(x => `${x.id} ${x.name} ${x.type} ${x.result}`.toLowerCase().includes(q)) : sourceRows;
  }, [query, sourceRows]);

  return (
    <div className="mx-auto max-w-6xl space-y-6 fade-in">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-[0.18em] text-[#118f87]">Doctor workspace</div>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-[#10243e] md:text-[38px]">Screening queue</h1>
          <p className="mt-2 max-w-2xl text-[14px] leading-6 text-[#6f8299]">A familiar appointment-style case list adapted for explainable retinal screening review.</p>
        </div>
        <StatusBadge tone="warning">{pendingRows.length} awaiting review</StatusBadge>
      </div>

      <section className="overflow-hidden rounded-[28px] border border-[#dce6ef] bg-white shadow-soft">
        <div className="border-b border-[#dce6ef] px-5 pt-5 md:px-6">
          <div className="flex items-center gap-7">
            {["Upcoming","Past"].map(t => (
              <button key={t} onClick={() => setTab(t)}
                className={`border-b-2 px-1 pb-3 text-[14px] font-extrabold ${tab===t ? "border-[#118f87] text-[#0d6f69]" : "border-transparent text-[#8b9bae]"}`}>
                {t}{t === "Past" && pastRows.length ? ` · ${pastRows.length}` : ""}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-3 border-b border-[#dce6ef] p-4 md:flex-row">
          <div className="flex flex-1 items-center gap-2 rounded-xl border border-[#dce6ef] bg-[#f7fafc] px-3">
            <Search size={16} className="text-[#8297aa]" />
            <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search patient or screening ID" className="w-full bg-transparent py-3 text-[13px] font-bold text-[#294760] outline-none placeholder:text-[#9aacbc]" />
          </div>
          <button className="inline-flex items-center justify-center gap-2 rounded-xl border border-[#dce6ef] px-4 py-3 text-[12px] font-extrabold text-[#526b82]"><Filter size={14}/> Filter</button>
        </div>

        <div className="bg-[#f5f9fc] p-4 md:p-5">
          <div className="space-y-3">
            {visible.map(r => (
              <article key={r.id} className="group flex flex-col overflow-hidden rounded-2xl border border-[#dce6ef] bg-white shadow-[0_6px_24px_rgba(15,23,42,.045)] transition hover:-translate-y-0.5 hover:border-[#b6dfdb] hover:shadow-soft md:flex-row">
                <div className="flex min-w-[116px] items-center justify-center border-b border-[#dce6ef] bg-gradient-to-b from-[#eaf8f6] to-white px-4 py-4 md:border-b-0 md:border-r">
                  <div className="text-center">
                    <div className="text-[11px] font-extrabold uppercase tracking-[0.18em] text-[#8297aa]">{r.month}</div>
                    <div className="mt-1 text-4xl font-extrabold leading-none text-[#0d6f69]">{r.day}</div>
                    <div className="mt-1 text-[10px] font-extrabold uppercase tracking-[0.16em] text-[#8297aa]">{r.week}</div>
                  </div>
                </div>
                <div className="flex flex-1 flex-col gap-4 p-5 md:flex-row md:items-center">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="text-[17px] font-extrabold text-[#10243e]">{r.name}</h2>
                      <StatusBadge tone={r.tone}>{r.decision}</StatusBadge>
                    </div>
                    <div className="mt-2 flex flex-wrap gap-x-5 gap-y-2 text-[12px] font-bold text-[#74889c]">
                      <span className="flex items-center gap-1.5"><Clock3 size={13}/> {r.time}</span>
                      <span className="flex items-center gap-1.5"><Stethoscope size={13}/> {r.type}</span>
                      <span className="flex items-center gap-1.5"><UserRound size={13}/> {r.id}</span>
                    </div>
                  </div>
                  <div className="min-w-[210px] border-t border-[#e6edf2] pt-3 md:border-l md:border-t-0 md:pl-5 md:pt-0">
                    <div className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#8799ab]">AI result</div>
                    <div className="mt-1 text-[13px] font-extrabold text-[#294760]">{r.result}</div>
                    <div className="mt-1 text-[12px] font-bold text-[#8194a7]">{r.confidence} calibrated confidence</div>
                  </div>
                  <div className="md:w-[118px]">
                    <div className="mb-2 hidden text-[10px] font-extrabold uppercase tracking-[0.14em] text-[#8799ab] md:block">Action</div>
                    {r.reviewed ? (
                      <Link to={`/reports/${r.id}`} className="inline-flex w-full items-center justify-center gap-1.5 rounded-xl border border-[#dce6ef] bg-white px-3 py-3 text-[12px] font-extrabold text-[#294760] hover:border-[#9fd4d0] hover:text-[#0d6f69]">View report <ArrowRight size={13}/></Link>
                    ) : (
                      <Link to={`/review/${r.id}`} className="inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-[#10243e] px-3 py-3 text-[12px] font-extrabold text-white group-hover:bg-[#118f87]">Review <ArrowRight size={13}/></Link>
                    )}
                  </div>
                </div>
              </article>
            ))}
            {visible.length === 0 && (
              <div className="rounded-2xl border border-dashed border-[#cbd8e3] bg-white p-10 text-center">
                <CalendarDays className="mx-auto text-[#b4c3cf]" size={26} />
                <div className="mt-3 text-[14px] font-extrabold text-[#294760]">{tab === "Upcoming" ? "No cases awaiting review" : "No reviewed cases yet"}</div>
                <div className="mt-1 text-[11px] font-bold text-[#8b9bae]">{query ? "Try a patient name or screening ID." : tab === "Upcoming" ? "All current screenings have been reviewed." : "Reviewed screenings will appear here."}</div>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
