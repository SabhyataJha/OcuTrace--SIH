import React, { useCallback, useEffect, useMemo, useState } from "react";
import {
  Activity, AlertTriangle, ArrowRight, CalendarDays, CheckCircle2, ChevronRight,
  Clock3, FileText, Plus, ScanLine, ShieldAlert, UsersRound, Eye, Sparkles
} from "lucide-react";
import { Link } from "react-router-dom";
import StatusBadge from "../components/StatusBadge";
import { listScreenings } from "../services/api";

const gradeNames = ["No DR", "Mild NPDR", "Moderate NPDR", "Severe NPDR", "PDR"];

function relativeTime(timestamp, now) {
  if (!timestamp) return "—";
  const mins = Math.max(0, Math.floor((now - new Date(timestamp).getTime()) / 60000));
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hr${hrs === 1 ? "" : "s"} ago`;
  return `${Math.floor(hrs / 24)} day${Math.floor(hrs / 24) === 1 ? "" : "s"} ago`;
}

function initials(name = "Patient") { return name.split(/\s+/).map((x) => x[0]).join("").slice(0, 2).toUpperCase(); }
function formatDate(d) { return new Intl.DateTimeFormat("en-IN", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(d); }
function formatTime(d) { return new Intl.DateTimeFormat("en-IN", { hour: "numeric", minute: "2-digit", second: "2-digit" }).format(d); }

function StatCard({ icon: Icon, label, value, note, tone, to }) {
  const body = <div className={`ot-stat ${tone}`}><div className="ot-stat-icon"><Icon size={19} /></div><div className="min-w-0"><div className="ot-stat-label">{label}</div><div className="ot-stat-value">{value}</div><div className="ot-stat-note">{note}</div></div></div>;
  return to ? <Link to={to}>{body}</Link> : body;
}

export default function Dashboard() {
  const [screenings, setScreenings] = useState([]);
  const [now, setNow] = useState(() => new Date());
  const refresh = useCallback(async () => { const data = await listScreenings(); setScreenings(Array.isArray(data) ? data : []); }, []);

  useEffect(() => {
    refresh();
    const sync = () => refresh();
    window.addEventListener("retinascope:data-changed", sync);
    window.addEventListener("focus", sync);
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => { window.removeEventListener("retinascope:data-changed", sync); window.removeEventListener("focus", sync); clearInterval(timer); };
  }, [refresh]);

  const pending = useMemo(() => screenings.filter(s => !s?.review), [screenings]);
  const reviewed = useMemo(() => screenings.filter(s => !!s?.review), [screenings]);
  const referable = useMemo(() => screenings.filter(s => s?.decision?.referral === "referable"), [screenings]);
  const todayCount = useMemo(() => { const start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime(); return screenings.filter(s => new Date(s?.timestamps?.created || 0).getTime() >= start).length; }, [screenings, now]);
  const uniquePatients = useMemo(() => new Set(screenings.map(s => s?.patient?.id).filter(Boolean)).size, [screenings]);
  const recent = useMemo(() => [...screenings].sort((a,b) => new Date(b?.timestamps?.created||0)-new Date(a?.timestamps?.created||0)).slice(0,5), [screenings]);
  const grades = useMemo(() => { const c=[0,0,0,0,0]; screenings.forEach(s => { const g=Number(s?.prediction?.grade); if(Number.isInteger(g)&&g>=0&&g<=4)c[g]++; }); return c; }, [screenings]);
  const totalGrades = grades.reduce((a,b)=>a+b,0) || 1;
  const greeting = now.getHours() < 12 ? "Good morning" : now.getHours() < 17 ? "Good afternoon" : "Good evening";
  const referablePct = screenings.length ? Math.round((referable.length/screenings.length)*100) : 0;
  const reviewedPct = screenings.length ? Math.round((reviewed.length/screenings.length)*100) : 0;

  return <div className="ot-dashboard fade-in">
    <section className="ot-hero">
      <div className="ot-hero-decoration one" /><div className="ot-hero-decoration two" />
      <div className="relative z-10 flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="ot-kicker"><span className="ot-live-dot" /> Screening control center</div>
          <h1>{greeting}, Doctor.</h1>
          <p>Monitor retinal screenings, prioritize cases that need review, and move confidently from AI evidence to a documented clinical decision.</p>
          <div className="ot-live-meta"><CalendarDays size={14}/><span>{formatDate(now)}</span><i/><Clock3 size={14}/><strong>{formatTime(now)}</strong><span className="ot-realtime">● REAL-TIME</span></div>
        </div>
        <div className="ot-hero-actions"><Link to="/queue" className="ot-outline-btn"><Eye size={16}/> Review queue <span>{pending.length}</span></Link><Link to="/screen/new" className="ot-primary-btn"><Plus size={17}/> New screening</Link></div>
      </div>
    </section>

    <section className="ot-stats-grid">
      <StatCard icon={ScanLine} label="Today's screenings" value={todayCount} note="Cases created today" tone="blue" to="/queue" />
      <StatCard icon={Clock3} label="Pending reviews" value={pending.length} note={pending.length ? "Requires your attention" : "All cases reviewed"} tone="amber" to="/queue" />
      <StatCard icon={ShieldAlert} label="Referable cases" value={referable.length} note={`${referablePct}% of current screenings`} tone="red" to="/queue" />
      <StatCard icon={UsersRound} label="Patients screened" value={uniquePatients} note="Unique patients in workspace" tone="green" to="/patients" />
    </section>

    <section className="ot-main-grid">
      <div className="ot-card ot-recent-card">
        <div className="ot-card-head"><div><div className="ot-section-label"><Activity size={13}/> Live activity</div><h2>Recent screenings</h2><p>Latest cases entering the clinical workflow</p></div><Link to="/queue" className="ot-view-link">View all <ArrowRight size={14}/></Link></div>
        <div>
          {recent.length ? recent.map(s => {
            const risk=s?.decision?.referral === "referable", done=!!s?.review;
            return <div className="ot-case" key={s.screeningId}>
              <div className={`ot-case-avatar ${risk ? "risk":"safe"}`}>{initials(s?.patient?.name)}</div>
              <div className="min-w-0 flex-1"><div className="ot-case-title"><strong>{s?.patient?.name || "Unnamed patient"}</strong><StatusBadge tone={risk?"danger":"good"}>{risk?"Referable":"Routine"}</StatusBadge>{done&&<span className="ot-reviewed"><CheckCircle2 size={12}/> Reviewed</span>}</div><div className="ot-case-meta"><span>{s.screeningId}</span><b>•</b><span>Grade {s?.prediction?.grade ?? "—"} · {s?.prediction?.label || "DR screening"}</span><b>•</b><span>{relativeTime(s?.review?.timestamp || s?.timestamps?.created, now.getTime())}</span></div></div>
              <Link to={done?`/reports/${s.screeningId}`:`/review/${s.screeningId}`} className="ot-case-action">{done?"Report":"Review"}<ChevronRight size={15}/></Link>
            </div>;
          }) : <div className="ot-empty">No screening activity yet.</div>}
        </div>
        <Link to="/queue" className="ot-card-footer">Open screening queue <ArrowRight size={14}/></Link>
      </div>

      <div className="ot-card ot-overview-card">
        <div className="ot-card-head compact"><div><div className="ot-section-label"><Sparkles size={13}/> Clinical overview</div><h2>Today's workload</h2></div></div>
        <div className="ot-workload-grid">
          <div className="ot-workload amber"><Clock3 size={17}/><strong>{pending.length}</strong><span>Awaiting review</span></div>
          <div className="ot-workload red"><AlertTriangle size={17}/><strong>{referable.length}</strong><span>Referable</span></div>
          <div className="ot-workload green"><CheckCircle2 size={17}/><strong>{reviewed.length}</strong><span>Reviewed</span></div>
          <div className="ot-workload blue"><FileText size={17}/><strong>{screenings.length}</strong><span>Total screenings</span></div>
        </div>
        <div className="ot-distribution">
          <div className="ot-dist-head"><div><span>DR grade distribution</span><small>Current workspace</small></div><span>{reviewedPct}% reviewed</span></div>
          <div className="ot-donut-wrap"><div className="ot-donut" style={{background:`conic-gradient(#16a085 0 ${(grades[0]/totalGrades)*100}%, #2f80d7 ${(grades[0]/totalGrades)*100}% ${((grades[0]+grades[1])/totalGrades)*100}%, #f2ae2e ${((grades[0]+grades[1])/totalGrades)*100}% ${((grades[0]+grades[1]+grades[2])/totalGrades)*100}%, #e34b55 ${((grades[0]+grades[1]+grades[2])/totalGrades)*100}% ${((grades[0]+grades[1]+grades[2]+grades[3])/totalGrades)*100}%, #8b5cf6 ${((grades[0]+grades[1]+grades[2]+grades[3])/totalGrades)*100}% 100%)`}}><div><strong>{screenings.length}</strong><span>cases</span></div></div><div className="ot-legend">{grades.slice(0,4).map((n,i)=><div key={i}><i className={`g${i}`}/><span>Grade {i}<small>{gradeNames[i]}</small></span><strong>{n}</strong></div>)}</div></div>
        </div>
        <div className="ot-updated"><span className="ot-live-dot"/> Updated just now · Live workspace</div>
      </div>
    </section>

    <section className="ot-bottom-grid">
      <div className="ot-card ot-quick-card"><div className="ot-card-head compact"><div><div className="ot-section-label"><Sparkles size={13}/> Shortcuts</div><h2>Quick actions</h2></div></div><div className="ot-quick-grid">
        <Link to="/screen/new" className="ot-quick blue"><div><ScanLine size={19}/></div><span><strong>New screening</strong><small>Upload a validated fundus image</small></span><ArrowRight size={16}/></Link>
        <Link to="/patients" className="ot-quick green"><div><UsersRound size={19}/></div><span><strong>Patient records</strong><small>Search and review patient history</small></span><ArrowRight size={16}/></Link>
        <Link to="/reports" className="ot-quick violet"><div><FileText size={19}/></div><span><strong>Clinical reports</strong><small>View completed screening reports</small></span><ArrowRight size={16}/></Link>
      </div></div>

      <div className="ot-card ot-insight-card"><div className="ot-card-head compact"><div><div className="ot-section-label"><ShieldAlert size={13}/> Priority insight</div><h2>Clinical attention</h2></div></div><div className="ot-insight-body"><div className="ot-insight-ring"><strong>{pending.length}</strong><span>pending</span></div><div><strong>{pending.length ? "Cases need your review" : "Queue is clear"}</strong><p>{referable.length ? `${referable.length} referable case${referable.length===1?"":"s"} currently require clinical attention.` : "No referable cases are currently flagged."}</p><Link to="/queue">Open review queue <ArrowRight size={13}/></Link></div></div><div className="ot-insight-strip"><CheckCircle2 size={14}/> Patient records and review status stay synchronized across the workspace.</div></div>
    </section>

    <div className="ot-footer-note"><span className="ot-live-dot"/><span><strong>OcuTrace demo workspace.</strong> Local screening records are synchronized across Dashboard, Queue, Patient Records and Reports.</span></div>
  </div>;
}
