import React from "react";
import { ArrowRight, FileText } from "lucide-react";
import { Link } from "react-router-dom";

export default function Reports() {
  return (
    <div className="space-y-6 fade-in">
      <div>
        <div className="text-[11px] font-bold uppercase tracking-[0.18em] text-teal-700">Reporting</div>
        <h1 className="mt-2 text-2xl font-extrabold tracking-tight">Reports</h1>
        <p className="mt-2 text-sm text-slate-500">Structured outputs generated from screening results and human review.</p>
      </div>
      <div className="grid gap-3">
        {[
          ["DR-2026-00842", "Aarav Kumar", "Grade 2 · Moderate NPDR", "Referable"],
          ["DR-2026-00840", "Rahul Sharma", "Grade 3 · Severe NPDR", "Referable"],
        ].map((r) => (
          <div key={r[0]} className="flex flex-col justify-between gap-3 rounded-2xl border border-slate-200/80 bg-white p-4 shadow-soft md:flex-row md:items-center">
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-teal-50 text-teal-700"><FileText size={17} /></div>
              <div><div className="text-xs font-bold">{r[1]}</div><div className="mt-1 text-[10px] text-slate-400">{r[0]} · {r[2]}</div></div>
            </div>
            <div className="flex items-center gap-3">
              <span className="rounded-full bg-rose-50 px-2.5 py-1 text-[10px] font-bold text-rose-700">{r[3]}</span>
              <Link to={`/reports/${r[0]}`} className="inline-flex items-center gap-1 rounded-xl bg-slate-950 px-3 py-2 text-[10px] font-bold text-white">Open <ArrowRight size={12} /></Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}