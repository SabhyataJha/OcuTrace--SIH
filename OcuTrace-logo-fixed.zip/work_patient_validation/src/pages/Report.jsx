import React, { useEffect, useState } from "react";
import { ArrowLeft, CheckCircle2, Download, FileText, ShieldCheck, Stethoscope } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { getScreening } from "../services/api";
import StatusBadge from "../components/StatusBadge";

function printReport() {
  window.print();
}

export default function Report() {
  const { id } = useParams();
  const [screening, setScreening] = useState(null);

  useEffect(() => {
    getScreening(id).then(setScreening);
  }, [id]);

  if (!screening) {
    return (
      <div className="rounded-2xl border border-slate-200 bg-white p-10 shadow-soft">
        <div className="shimmer h-5 w-48 rounded" />
        <div className="mt-4 shimmer h-72 w-full rounded-2xl" />
      </div>
    );
  }

  const confidencePct = Math.round(screening.confidence.calibrated * 100);
  const referral = screening.decision.referral === "referable";
  const reviewDecision = screening.review?.decision || "Pending human review";
  const decisionLabel = reviewDecision === "confirm"
    ? "AI recommendation confirmed"
    : reviewDecision === "override_refer"
      ? "Overridden · Refer"
      : reviewDecision === "override_routine"
        ? "Overridden · Routine"
        : "Awaiting doctor review";

  return (
    <div className="mx-auto max-w-6xl space-y-5 fade-in print-report">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between print:hidden">
        <div>
          <div className="text-[12px] font-extrabold uppercase tracking-[0.18em] text-teal-700">Structured clinical report</div>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-slate-950">Screening report</h1>
          <p className="mt-2 max-w-2xl text-[16px] leading-7 text-slate-500">A clinician-ready summary of the retinal screening, model assessment and human review state.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to={`/review/${id}`} className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-3 text-[14px] font-extrabold text-slate-700 transition hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-md">
            <ArrowLeft size={17} /> Back to review
          </Link>
          <button onClick={printReport} className="inline-flex items-center gap-2 rounded-xl bg-slate-950 px-5 py-3 text-[14px] font-extrabold text-white transition hover:-translate-y-0.5 hover:bg-teal-700 hover:shadow-lg">
            <Download size={17} /> Print / Save PDF
          </button>
        </div>
      </div>

      <section className="overflow-hidden rounded-[30px] border border-slate-200/80 bg-white shadow-[0_24px_70px_rgba(16,36,62,.08)] print:rounded-none print:border print:shadow-none">
        <header className="report-hero relative overflow-hidden border-b border-slate-100 bg-[linear-gradient(135deg,#f7fbfd_0%,#eef8f7_56%,#f4f8ff_100%)] px-7 py-7 sm:px-9 sm:py-8 print:bg-white">
          <div className="pointer-events-none absolute -right-20 -top-24 h-72 w-72 rounded-full bg-teal-400/10 blur-3xl print:hidden" />
          <div className="relative flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
            <div className="flex gap-4">
              <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-white text-teal-700 shadow-sm ring-1 ring-slate-200/70 print:bg-slate-50">
                <FileText size={24} />
              </div>
              <div>
                <div className="text-[12px] font-extrabold uppercase tracking-[0.16em] text-slate-400">RETINASCOPE SCREENING REPORT</div>
                <div className="mt-2 flex flex-wrap items-center gap-2 text-[13px] font-bold text-slate-500">
                  <span>{screening.screeningId}</span><span>·</span><span>{new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}</span>
                </div>
              </div>
            </div>
            <StatusBadge tone={referral ? "danger" : "good"}>
              {referral ? "Referable" : "Routine"}
            </StatusBadge>
          </div>

          <div className="relative mt-7 grid gap-4 lg:grid-cols-[1.25fr_.75fr]">
            <div className="rounded-3xl border border-white/80 bg-white/85 p-5 shadow-sm backdrop-blur-sm print:bg-white">
              <div className="text-[11px] font-extrabold uppercase tracking-[0.16em] text-slate-400">PATIENT</div>
              <div className="mt-2 text-2xl font-extrabold text-slate-950">{screening.patient.name}</div>
              <div className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-[14px] font-semibold text-slate-500">
                <span>{screening.patient.age} years</span>
                <span>{screening.patient.sex}</span>
                <span>ID {screening.patient.id}</span>
              </div>
            </div>
            <div className="rounded-3xl border border-white/20 bg-[#123e63] p-5 text-white shadow-sm">
              <div className="text-[11px] font-extrabold uppercase tracking-[0.16em] text-white/45">FINAL STATUS</div>
              <div className="mt-2 text-2xl font-extrabold">{referral ? "Referable" : "Routine"}</div>
              <div className="mt-2 text-[13px] font-semibold text-white/60">{decisionLabel}</div>
            </div>
          </div>
        </header>

        <section className="grid gap-4 p-6 sm:grid-cols-2 xl:grid-cols-3 print:grid-cols-3 print:p-5">
          {[
            ["DR GRADE", `Grade ${screening.prediction.grade}`, screening.prediction.label, "text-slate-950"],
            ["CALIBRATED CONFIDENCE", `${confidencePct}%`, "After calibration", "text-teal-700"],
            ["REFERRAL", referral ? "Referable" : "Routine", "Deterministic decision rule", referral ? "text-rose-700" : "text-emerald-700"],
          ].map(([label, value, sub, tone]) => (
            <div key={label} className="report-stat rounded-2xl border border-slate-200 bg-slate-50/70 p-5 transition hover:-translate-y-1 hover:bg-white hover:shadow-md print:bg-white print:shadow-none">
              <div className="text-[11px] font-extrabold uppercase tracking-[0.14em] text-slate-400">{label}</div>
              <div className={`mt-3 text-2xl font-extrabold tracking-tight ${tone}`}>{value}</div>
              <div className="mt-1 text-[13px] font-semibold text-slate-500">{sub}</div>
            </div>
          ))}
        </section>

        <section className="grid gap-5 border-t border-slate-100 px-6 py-6 lg:grid-cols-[1.2fr_.8fr] print:grid-cols-[1.15fr_.85fr] print:px-5">
          <div className="rounded-3xl border border-slate-200 bg-white p-6">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-[11px] font-extrabold uppercase tracking-[0.14em] text-teal-700">CLINICAL SUMMARY</div>
                <h2 className="mt-1 text-xl font-extrabold text-slate-950">Screening interpretation</h2>
              </div>
              <div className="grid h-11 w-11 place-items-center rounded-2xl bg-teal-50 text-teal-700"><Stethoscope size={20} /></div>
            </div>
            <div className="mt-5 rounded-2xl bg-slate-50 p-5">
              <div className="text-[17px] font-extrabold text-slate-950">{screening.prediction.label}</div>
              <p className="mt-2 text-[14px] leading-7 text-slate-600">The automated screening assessment is <strong>{confidencePct}% calibrated confidence</strong>. Review the retinal image and lesion evidence in the case review before using this report for clinical decision-making.</p>
            </div>
            <div className="mt-4">
              <div className="rounded-2xl border border-slate-200 p-4"><div className="text-[11px] font-extrabold uppercase tracking-[0.12em] text-slate-400">Review state</div><div className="mt-2 text-[15px] font-extrabold text-slate-900">{decisionLabel}</div></div>
            </div>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-[linear-gradient(180deg,#fbfdff,#f6fbfa)] p-6">
            <div className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.14em] text-slate-400"><ShieldCheck size={16} className="text-teal-700" /> Human review</div>
            <div className="mt-5 flex items-start gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-2xl bg-emerald-50 text-emerald-700"><CheckCircle2 size={19} /></div>
              <div>
                <div className="text-[17px] font-extrabold text-slate-950">{decisionLabel}</div>
                <div className="mt-1 text-[13px] font-semibold text-slate-500">Recorded against case {screening.screeningId}.</div>
              </div>
            </div>
            <div className="mt-6 h-px bg-slate-200" />
            <div className="mt-5 text-[11px] font-extrabold uppercase tracking-[0.14em] text-slate-400">Clinical note</div>
            <p className="mt-2 text-[14px] leading-7 text-slate-600">{screening.review?.comment || "No additional clinical note was recorded."}</p>
          </div>
        </section>

        <footer className="border-t border-slate-100 px-6 py-5 text-[12px] leading-6 text-slate-400 print:px-5">
          Screening aid only. This report does not replace ophthalmologist assessment or clinical judgment.
        </footer>
      </section>
    </div>
  );
}
