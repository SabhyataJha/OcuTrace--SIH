import React, { useEffect, useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  FileText,
  Info,
  Layers3,
  ShieldCheck,
  Sparkles,
  Target,
  Activity,
  CircleDot,
  BadgeCheck,
  GitBranch,
  MessageSquareText,
  Stethoscope,
  RotateCcw,
} from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { getScreening, submitReview } from "../services/api";
import FundusViewer from "../components/FundusViewer";
import StatusBadge from "../components/StatusBadge";

export default function DoctorReview() {
  const { id } = useParams();
  const [screening, setScreening] = useState(null);
  const [decision, setDecision] = useState("");
  const [comment, setComment] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [activeLayer, setActiveLayer] = useState("original");
  const [selectedLesion, setSelectedLesion] = useState(null);

  useEffect(() => {
    getScreening(id).then((data) => {
      setScreening(data);
      setSaved(Boolean(data?.review));
      if (data?.review?.decision) setDecision(data.review.decision);
      if (data?.review?.comment) setComment(data.review.comment);
    });
  }, [id]);

  if (!screening) {
    return <div className="rounded-2xl border border-slate-200 bg-white p-10 shadow-soft"><div className="shimmer h-5 w-48 rounded" /><div className="mt-4 shimmer h-96 w-full rounded-2xl" /></div>;
  }

  const confidencePct = Math.round(screening.confidence.calibrated * 100);
  const referral = screening.decision.referral === "referable";

  async function review() {
    if (!decision) return;
    setSaving(true);
    const result = await submitReview(id, { decision, comment });
    setSaving(false);
    setSaved(result.ok);
  }

  function focusLesion(lesion, index) {
    setSelectedLesion(index);
    setActiveLayer("lesions");
  }

  return (
    <div className="space-y-5 fade-in">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <h1 className="mt-2 text-[32px] font-extrabold tracking-tight">Screening review</h1>
          <p className="mt-2 text-[16px] text-slate-600">Review the retinal image with patient context and the strongest evidence visible at the point of decision.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <StatusBadge tone={referral ? "danger" : "good"}>{referral ? "Referable" : "Routine"}</StatusBadge>
          <StatusBadge tone="good">{confidencePct}% calibrated confidence</StatusBadge>
        </div>
      </div>

      <div className="grid items-start gap-5 xl:grid-cols-[250px_minmax(500px,1fr)_360px]">
        {/* LEFT: single patient context rail */}
        <aside className="space-y-4 xl:sticky xl:top-5">
          <section className="overflow-hidden rounded-3xl border border-[#dce6ef] bg-white shadow-clinical rs-lift">
            <div className="relative overflow-hidden bg-gradient-to-br from-[#0f5d72] via-[#118f87] to-[#2b6cb0] px-5 pb-5 pt-5 text-white">
              <div className="relative flex items-start justify-between gap-3">
                <div>
                  <div className="text-[15px] font-extrabold uppercase tracking-[0.18em] text-white/60">Patient context</div>
                  <div className="mt-2 text-[20px] font-extrabold tracking-tight">{screening.patient.name}</div>
                  <div className="mt-1 text-[15px] font-semibold text-white/70">{screening.patient.age} years · {screening.patient.sex}</div>
                </div>
                <div className="grid h-10 w-10 place-items-center rounded-2xl bg-white/10 ring-1 ring-white/20"><Activity size={17} /></div>
              </div>
              <div className="relative mt-4 rounded-2xl border border-white/10 bg-white/10 p-3 backdrop-blur-sm">
                <div className="text-[11px] font-bold uppercase tracking-[0.14em] text-white/55">Current screening</div>
                <div className="mt-1 text-[15px] font-extrabold text-white">{screening.screeningId}</div>
              </div>
            </div>

            <div className="p-4">
              <div className="grid grid-cols-2 gap-2">
                {[
                  ["Patient ID", screening.patient.id],
                  ["Diabetes", `${screening.patient.diabetesDuration} yrs`],
                  ["HbA1c", `${screening.patient.hbA1c}%`],
                  ["Status", "Active case"],
                ].map(([label, value]) => (
                  <div key={label} className="rounded-2xl border border-slate-100 bg-slate-50/80 p-2.5 transition hover:-translate-y-0.5 hover:border-teal-100 hover:bg-teal-50/40">
                    <div className="text-[8px] font-bold uppercase tracking-[0.12em] text-slate-400">{label}</div>
                    <div className="mt-1 truncate text-[11px] font-extrabold text-slate-800">{value}</div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="rounded-3xl border border-slate-200/80 bg-white p-4 shadow-clinical rs-lift">
            <div className="flex items-center justify-between">
              <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-slate-400">Image quality gate</div>
              <span className="rounded-full bg-emerald-50 px-2 py-1 text-[8px] font-extrabold text-emerald-700">PASS</span>
            </div>
            <div className="mt-3 flex items-end justify-between">
              <div className="text-3xl font-extrabold tracking-tight text-slate-950">{screening.quality.score}</div>
              <div className="text-[12px] font-bold text-emerald-600">Gradable</div>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100">
              <div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-600" style={{ width: `${screening.quality.score}%` }} />
            </div>
            <div className="mt-4 space-y-2.5">
              {screening.quality.reasons.map((x) => (
                <div key={x.label} className="flex items-center justify-between text-[10px]">
                  <span className="text-slate-400">{x.label}</span>
                  <span className="font-bold text-emerald-600">{x.value}</span>
                </div>
              ))}
            </div>
          </section>
        </aside>

        {/* CENTER: main retinal evidence */}
        <div className="min-w-0">
          <FundusViewer screening={screening} activeLayer={activeLayer} onActiveLayerChange={setActiveLayer} />
        </div>

        {/* RIGHT: priority evidence rail */}
        <aside className="space-y-4 xl:sticky xl:top-5">
          <section className="lesion-priority-panel overflow-hidden rounded-3xl border border-teal-100 bg-white shadow-[0_18px_50px_rgba(15,118,110,.10)]">
            <div className="relative overflow-hidden bg-gradient-to-br from-[#0b4352] via-[#0f766e] to-[#2b6cb0] px-5 pb-5 pt-5 text-white">
              <div className="relative flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.16em] text-white/70"><Sparkles size={11} /> Priority evidence</div>
                  <div className="mt-2 text-[18px] font-extrabold">Lesion evidence</div>
                  <div className="mt-1 text-[14px] leading-7 text-white/72">Pixel-level findings that support the screening decision.</div>
                </div>
                <div className="rounded-xl bg-white/10 px-2.5 py-1.5 text-center ring-1 ring-white/15">
                  <div className="text-[15px] font-extrabold">{screening.evidence.lesions.length}</div>
                  <div className="text-[7px] font-bold uppercase tracking-[0.12em] text-white/60">classes</div>
                </div>
              </div>
            </div>

            <div className="p-4">
              <div className="mb-3 flex items-center gap-2 rounded-2xl border border-rose-100 bg-rose-50/70 px-3 py-2.5 text-[11px] font-bold text-rose-800">
                <Target size={13} /> Click a finding to inspect it on the retinal image
              </div>

              <div className="space-y-3">
                {screening.evidence.lesions.map((lesion, index) => {
                  const isHemorrhage = lesion.type.toLowerCase().includes("haem") || lesion.type.toLowerCase().includes("hem");
                  const isSelected = selectedLesion === index;
                  const pct = Math.round(lesion.confidence * 100);
                  return (
                    <button
                      type="button"
                      key={lesion.type}
                      onClick={() => focusLesion(lesion, index)}
                      className={[
                        "group relative w-full overflow-hidden rounded-2xl border p-4 text-left transition duration-200",
                        "hover:-translate-y-1 hover:shadow-[0_16px_35px_rgba(15,23,42,.10)]",
                        isHemorrhage ? "border-rose-200 bg-rose-50/70" : "border-amber-200 bg-amber-50/80",
                        isSelected ? "ring-2 ring-offset-2 ring-rose-400" : "",
                      ].join(" ")}
                    >
                      <div className={[
                        "absolute inset-y-0 left-0 w-1 transition",
                        isHemorrhage ? "bg-rose-500" : "bg-amber-400",
                      ].join(" ")} />
                      <div className="flex items-start justify-between gap-3 pl-1">
                        <div className="flex min-w-0 items-center gap-2.5">
                          <span className={[
                            "grid h-10 w-10 shrink-0 place-items-center rounded-xl text-white shadow-sm transition group-hover:scale-105",
                            isHemorrhage ? "bg-rose-500" : "bg-amber-400",
                          ].join(" ")}>
                            <CircleDot size={17} />
                          </span>
                          <div className="min-w-0">
                            <div className="truncate text-[15px] font-extrabold text-slate-900">{lesion.type}</div>
                            <div className="mt-0.5 text-[8px] font-bold uppercase tracking-[0.13em] text-slate-400">Lesion class {index + 1}</div>
                          </div>
                        </div>
                        <span className="rounded-full bg-white/80 px-2.5 py-1 text-[10px] font-extrabold text-slate-700 shadow-sm">{pct}%</span>
                      </div>

                      <div className="mt-4 grid grid-cols-2 gap-3 pl-1">
                        <div>
                          <div className="text-[23px] font-extrabold leading-none tracking-tight text-slate-950">{lesion.count}</div>
                          <div className="mt-1 text-[8px] font-bold uppercase tracking-[0.11em] text-slate-500">Instances</div>
                        </div>
                        <div>
                          <div className="text-[11px] font-bold text-slate-400">Model confidence</div>
                          <div className="mt-1 text-[14px] font-extrabold text-slate-800">{pct}%</div>
                        </div>
                      </div>

                      <div className="mt-3 pl-1">
                        <div className="h-2 overflow-hidden rounded-full bg-white/80">
                          <div className={[
                            "h-full rounded-full transition-all duration-500",
                            isHemorrhage ? "bg-rose-500" : "bg-amber-400",
                          ].join(" ")} style={{ width: `${pct}%` }} />
                        </div>
                      </div>

                      <div className="mt-3 flex items-center justify-between pl-1">
                        <span className="text-[11px] font-bold text-slate-500">{isSelected ? "Highlighted on image" : "Inspect on image"}</span>
                        <ArrowRight size={13} className="text-slate-400 transition group-hover:translate-x-0.5 group-hover:text-slate-700" />
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="mt-4 rounded-2xl border border-slate-200 bg-slate-50/80 p-3.5 transition hover:border-teal-200 hover:bg-teal-50/30">
                <div className="flex items-center gap-2 text-[15px] font-extrabold uppercase tracking-[0.13em] text-slate-500"><Info size={13} className="text-teal-600" /> Clinical interpretation</div>
                <p className="mt-2 text-[15px] leading-6 text-slate-500">Use the Lesion Map or Combined view to inspect location and distribution before confirming the final review state.</p>
              </div>
            </div>
          </section>

          <section className="rounded-3xl border border-teal-100 bg-gradient-to-br from-teal-50 to-white p-4 shadow-clinical rs-lift">
            <div className="flex items-center justify-between">
              <div className="text-[12px] font-bold uppercase tracking-[0.14em] text-teal-800">AI assessment</div>
              <StatusBadge tone="good">{confidencePct}%</StatusBadge>
            </div>
            <div className="mt-2 text-xl font-extrabold text-teal-950">{screening.prediction.label}</div>
            <div className="mt-1 text-[10px] text-teal-900/60">Grade {screening.prediction.grade} of 4</div>
            <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/90">
              <div className="h-full rounded-full bg-gradient-to-r from-teal-500 to-cyan-500" style={{ width: `${confidencePct}%` }} />
            </div>
          </section>

          <section className="rounded-3xl border border-slate-200/80 bg-white p-4 shadow-clinical rs-lift">
            <div className="flex items-center gap-2 text-[12px] font-bold"><ShieldCheck size={14} className="text-teal-700" /> Referral decision</div>
            <div className={[
              "mt-3 rounded-2xl border p-3.5",
              referral ? "border-rose-100 bg-rose-50" : "border-emerald-100 bg-emerald-50",
            ].join(" ")}>
              <div className={[
                "text-[15px] font-extrabold uppercase tracking-[0.14em]",
                referral ? "text-rose-700" : "text-emerald-700",
              ].join(" ")}>AI recommendation</div>
              <div className={[
                "mt-1 text-lg font-extrabold",
                referral ? "text-rose-900" : "text-emerald-900",
              ].join(" ")}>{referral ? "REFERABLE" : "ROUTINE"}</div>
              <div className="mt-1 text-[15px] leading-6 text-slate-600">{screening.decision.rationale}</div>
            </div>
          </section>
        </aside>
      </div>

      <section className="doctor-review-panel overflow-hidden rounded-[30px] border border-slate-200/80 bg-white shadow-[0_20px_55px_rgba(16,36,62,.08)]">
        <div className="relative border-b border-slate-100 bg-[linear-gradient(135deg,#f8fbfd_0%,#eef8f7_58%,#f5f9ff_100%)] px-6 py-6 sm:px-7">
          <div className="pointer-events-none absolute -right-16 -top-20 h-48 w-48 rounded-full bg-teal-400/10 blur-3xl" />
          <div className="relative flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.16em] text-teal-700">
                <Stethoscope size={14} /> Final clinical decision
              </div>
              <h2 className="mt-1.5 text-[24px] font-extrabold tracking-tight text-slate-950">DOCTOR REVIEW</h2>
              <p className="mt-1 max-w-2xl text-[14px] leading-7 text-slate-500">Choose the final review state after inspecting the retinal image and priority lesion evidence. Your choice is recorded in the audit trail.</p>
            </div>
            <div className="rounded-2xl border border-white/80 bg-white/80 px-4 py-3 shadow-sm backdrop-blur-sm">
              <div className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-slate-400">AI recommendation</div>
              <div className="mt-1 flex items-center gap-2">
                <span className={['h-2 w-2 rounded-full', referral ? 'bg-rose-500' : 'bg-emerald-500'].join(' ')} />
                <span className={['text-[15px] font-extrabold', referral ? 'text-rose-800' : 'text-emerald-800'].join(' ')}>{referral ? 'Referable' : 'Routine'}</span>
                <span className="text-[10px] font-semibold text-slate-400">· {confidencePct}% confidence</span>
              </div>
            </div>
          </div>
        </div>

        <div className="p-5 sm:p-6">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div>
              <div className="text-[11px] font-extrabold text-slate-900">Select the final outcome</div>
              <div className="mt-1 text-[10px] text-slate-400">The selected option becomes the human-reviewed case status.</div>
            </div>
            {decision && (
              <div className="inline-flex items-center gap-1.5 rounded-full border border-teal-100 bg-teal-50 px-3 py-1.5 text-[11px] font-extrabold text-teal-800">
                <CheckCircle2 size={12} /> Decision selected
              </div>
            )}
          </div>

          <div className="grid gap-3 md:grid-cols-3">
            {[
              {
                value: 'confirm',
                title: 'Confirm AI recommendation',
                detail: referral ? 'Keep the referable recommendation.' : 'Keep the routine recommendation.',
                icon: BadgeCheck,
                tone: referral ? 'rose' : 'emerald',
              },
              {
                value: 'override_refer',
                title: 'Override → Refer',
                detail: 'Escalate the case for specialist review.',
                icon: GitBranch,
                tone: 'rose',
              },
              {
                value: 'override_routine',
                title: 'Override → Routine',
                detail: 'Mark the case routine after clinical review.',
                icon: RotateCcw,
                tone: 'emerald',
              },
            ].map(({ value, title, detail, icon: Icon, tone }) => {
              const selected = decision === value;
              const rose = tone === 'rose';
              return (
                <button
                  key={value}
                  type="button"
                  onClick={() => setDecision(value)}
                  className={[
                    'decision-option group relative overflow-hidden rounded-2xl border p-4 text-left transition duration-200',
                    selected
                      ? (rose ? 'border-rose-300 bg-rose-50/80 shadow-[0_12px_28px_rgba(225,29,72,.10)]' : 'border-teal-300 bg-teal-50/80 shadow-[0_12px_28px_rgba(13,148,136,.10)]')
                      : 'border-slate-200 bg-white hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-[0_12px_28px_rgba(15,23,42,.08)]',
                  ].join(' ')}
                >
                  <div className={[
                    'absolute inset-x-0 top-0 h-1 transition-all',
                    selected ? (rose ? 'bg-rose-500' : 'bg-teal-600') : 'bg-transparent group-hover:bg-slate-200',
                  ].join(' ')} />
                  <div className="flex items-start justify-between gap-3">
                    <span className={[
                      'grid h-10 w-10 place-items-center rounded-xl transition duration-200 group-hover:scale-105',
                      selected
                        ? (rose ? 'bg-rose-100 text-rose-700' : 'bg-teal-100 text-teal-700')
                        : 'bg-slate-100 text-slate-500 group-hover:bg-slate-200',
                    ].join(' ')}>
                      <Icon size={18} />
                    </span>
                    <span className={[
                      'grid h-5 w-5 place-items-center rounded-full border transition',
                      selected
                        ? (rose ? 'border-rose-500 bg-rose-500 text-white' : 'border-teal-600 bg-teal-600 text-white')
                        : 'border-slate-200 bg-white text-transparent',
                    ].join(' ')}>
                      <CheckCircle2 size={12} />
                    </span>
                  </div>
                  <div className="mt-3 text-[15px] font-extrabold text-slate-900">{title}</div>
                  <div className="mt-1 text-[15px] leading-6 text-slate-500">{detail}</div>
                  <div className={[
                    'mt-3 text-[11px] font-bold uppercase tracking-[0.12em]',
                    selected ? (rose ? 'text-rose-700' : 'text-teal-700') : 'text-slate-400',
                  ].join(' ')}>
                    {selected ? 'Selected' : 'Choose this option'}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_320px]">
            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4 transition hover:border-slate-300 hover:bg-white">
              <div className="flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.13em] text-slate-500">
                <MessageSquareText size={14} className="text-teal-700" /> Clinical note
              </div>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder={decision?.startsWith('override_') ? 'Document the clinical reason for overriding the AI recommendation…' : 'Add a brief review note or supporting observation…'}
                className="mt-3 min-h-[120px] w-full resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-3 text-[14px] leading-7 text-slate-700 outline-none transition placeholder:text-slate-400 focus:border-teal-500 focus:ring-4 focus:ring-teal-500/10"
              />
              <div className="mt-2 flex items-center justify-between gap-3 text-[11px] text-slate-400">
                <span>{decision?.startsWith('override_') ? 'Recommended for overrides' : 'Optional · helps preserve review context'}</span>
                <span>{comment.length}/500</span>
              </div>
            </div>

            <div className="doctor-review-summary flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
              <div>
                <div className="text-[15px] font-extrabold uppercase tracking-[0.13em] text-slate-400">Before submission</div>
                <div className="mt-2 flex items-center gap-2">
                  <div className={[
                    'grid h-9 w-9 place-items-center rounded-xl',
                    referral ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600',
                  ].join(' ')}>
                    <ShieldCheck size={17} />
                  </div>
                  <div>
                    <div className="text-[11px] font-extrabold text-slate-900">{decision ? ({ confirm: 'AI recommendation confirmed', override_refer: 'Referral override', override_routine: 'Routine override' }[decision]) : 'No decision selected'}</div>
                    <div className="mt-0.5 text-[11px] text-slate-400">Case {screening.screeningId}</div>
                  </div>
                </div>
                <div className="mt-3 rounded-xl border border-slate-100 bg-slate-50 p-3 text-[11px] leading-5 text-slate-500">
                  The final decision is written to the case audit trail and reflected in the structured report.
                </div>
              </div>

              <button
                disabled={!decision || saving || saved}
                onClick={review}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-slate-950 px-4 py-3.5 text-[11px] font-extrabold text-white transition duration-200 hover:-translate-y-0.5 hover:bg-[#0b6f68] hover:shadow-[0_14px_30px_rgba(15,118,110,.20)] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:translate-y-0"
              >
                {saved ? <><CheckCircle2 size={15} /> Review recorded</> : saving ? 'Saving review…' : <><ShieldCheck size={15} /> Submit final review <ArrowRight size={14} /></>}
              </button>
            </div>
          </div>

          {saved && (
            <div className="mt-4 flex items-start gap-3 rounded-2xl border border-emerald-100 bg-emerald-50 p-4 text-[15px] leading-6 text-emerald-800">
              <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-emerald-600" />
              <div><span className="font-extrabold">Review recorded.</span> Audit entry created for {screening.screeningId}. The reviewed state is now available to the structured report.</div>
            </div>
          )}
        </div>
      </section>


      <div className="flex flex-wrap gap-2">
        <Link to={`/reports/${id}`} className="inline-flex items-center gap-2 rounded-xl bg-teal-700 px-4 py-3 text-xs font-bold text-white transition hover:-translate-y-0.5 hover:shadow-lg">
          <FileText size={15} /> Open report <ArrowRight size={14} />
        </Link>
      </div>
    </div>
  );
}
