/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        medical: {
          50: "#effcf9",
          100: "#d9f7f1",
          200: "#b7eee4",
          300: "#7ddfd1",
          400: "#3cc9b8",
          500: "#18ad9d",
          600: "#108d81",
          700: "#0f766e",
          800: "#115f5a",
          900: "#124f4b"
        },
        clinical: {
          50: "#eff6ff",
          100: "#dbeafe",
          600: "#2563eb",
          700: "#1d4ed8",
          900: "#1e3a8a"
        }
      },
      fontFamily: {
        sans: ["DM Sans", "ui-sans-serif", "system-ui", "sans-serif"],
        display: ["Manrope", "DM Sans", "ui-sans-serif", "system-ui", "sans-serif"]
      },
      boxShadow: {
        soft: "0 16px 45px rgba(15, 23, 42, 0.055)",
        clinical: "0 20px 55px rgba(15, 118, 110, 0.09)"
      }
    }
  },
  plugins: []
};